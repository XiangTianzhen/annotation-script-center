(function () {
  globalThis.ASREdgeBuildMeta = {
    releaseChannel: "beta",
    betaUnlockPasswordSha256: "6b45e23525092148c8eb251ab8599295a2d1bdcb9ad2e7827a25789b26cd947e",
    betaBackendBaseUrl: "http://47.109.197.170:3333",
  };
})();
