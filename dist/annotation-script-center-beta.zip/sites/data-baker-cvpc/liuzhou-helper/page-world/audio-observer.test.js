"use strict";

const assert = require("node:assert/strict");
const path = require("node:path");
const test = require("node:test");

const modulePath = path.resolve(__dirname, "audio-observer.js");
const OBSERVER_SOURCE = "ASR_EDGE_DATABAKER_CVPC_LIUZHOU_AUDIO_OBSERVER";
const OBSERVER_TYPE = "DATABAKER_CVPC_LIUZHOU_AUDIO_MAPPING";
const META_TYPE = "DATABAKER_CVPC_LIUZHOU_META_SNAPSHOT";
const AUTH_TYPE = "DATABAKER_CVPC_LIUZHOU_REQUEST_AUTH";

function loadObserverModule() {
  delete require.cache[modulePath];
  delete globalThis.ASREdgeDataBakerCvpcLiuzhouAudioObserverPage;
  return require(modulePath);
}

function createWindowHarness() {
  const postedMessages = [];
  return {
    window: {
      console: {
        log: function () {},
        info: function () {},
        debug: function () {},
        warn: function () {},
      },
      fetch: function () {
        throw new Error("fetch should not be called in observer unit tests");
      },
      postMessage: function (data, origin) {
        postedMessages.push({ data, origin });
      },
      XMLHttpRequest: function FakeXmlHttpRequest() {},
    },
    postedMessages,
  };
}

function createIframeWindowHarness() {
  const postedMessages = [];
  const parent = {
    postMessage: function (data, origin) {
      postedMessages.push({ data, origin, target: "parent" });
    },
  };
  return {
    window: {
      console: {
        log: function () {},
        info: function () {},
        debug: function () {},
        warn: function () {},
      },
      fetch: function () {
        throw new Error("fetch should not be called in observer unit tests");
      },
      parent,
      postMessage: function (data, origin) {
        postedMessages.push({ data, origin, target: "self" });
      },
      top: parent,
      XMLHttpRequest: function FakeXmlHttpRequest() {},
    },
    postedMessages,
  };
}

test("CVPC audio observer maps annotation meta relative content to captured signed audio url", function () {
  const observerModule = loadObserverModule();
  const harness = createWindowHarness();
  const observer = observerModule.createObserver({
    window: harness.window,
    location: {
      origin: "https://cvpc.data-baker.com",
      href: "https://cvpc.data-baker.com/app/editor/asr/",
    },
  });

  observer.observeResponse(
    "https://cvpc.data-baker.com/httpapi/annotation/meta?project_id=1&task_id=2",
    JSON.stringify({
      code: 0,
      data: {
        datas: [
          {
            entry_id: 249783,
            name: "20642_20643_20642_S0_segment_000001.mp3",
            content:
              "databaker/data/17896/0604_1_1780556161381/0604_1/20642_20643/20642_20643_20642_S0/20642_20643_20642_S0_segment_000001.mp3",
          },
        ],
      },
    })
  );
  observer.observeAudioUrl(
    "https://databaker-cvpc.oss-cn-huhehaote.aliyuncs.com/databaker/data/17896/0604_1_1780556161381/0604_1/20642_20643/20642_20643_20642_S0/20642_20643_20642_S0_segment_000001.mp3?OSSAccessKeyId=test&Signature=abc"
  );

  const snapshot = observer.getSnapshot();

  assert.equal(snapshot.mappings.length, 1);
  assert.equal(
    snapshot.mappings[0].relativePath,
    "databaker/data/17896/0604_1_1780556161381/0604_1/20642_20643/20642_20643_20642_S0/20642_20643_20642_S0_segment_000001.mp3"
  );
  assert.equal(snapshot.mappings[0].fileName, "20642_20643_20642_S0_segment_000001.mp3");
  assert.match(snapshot.mappings[0].audioUrl, /OSSAccessKeyId=test/);
  const mappingMessages = harness.postedMessages.filter(function (item) {
    return item.data.type === OBSERVER_TYPE;
  });
  assert.equal(mappingMessages.length, 1);
  assert.equal(mappingMessages[0].origin, "https://cvpc.data-baker.com");
  assert.equal(mappingMessages[0].data.source, OBSERVER_SOURCE);
  assert.equal(mappingMessages[0].data.type, OBSERVER_TYPE);
});

test("CVPC audio observer posts code 200 annotation meta snapshot to isolated world", function () {
  const observerModule = loadObserverModule();
  const harness = createWindowHarness();
  const observer = observerModule.createObserver({
    window: harness.window,
    location: {
      origin: "https://cvpc.data-baker.com",
      href: "https://cvpc.data-baker.com/app/editor/asr/",
    },
  });

  observer.observeResponse(
    "https://cvpc.data-baker.com/httpapi/annotation/meta?project_id=1453&task_id=12099&process_id=4946&job_id=1520&data_id=17896",
    JSON.stringify({
      code: 200,
      data: {
        datas: [
          {
            entry_id: 249783,
            entry_index: 1,
            name: "sample.mp3",
            type: "audio",
            content: "databaker/data/17896/sample.mp3",
          },
        ],
        anns: [],
        template: {
          attrs: [],
          entry_attrs: [],
          moment_attrs: [],
        },
      },
    })
  );

  const metaMessage = harness.postedMessages.find(function (item) {
    return item.data.type === META_TYPE;
  });

  assert.ok(metaMessage);
  assert.equal(metaMessage.origin, "https://cvpc.data-baker.com");
  assert.equal(metaMessage.data.source, OBSERVER_SOURCE);
  assert.equal(metaMessage.data.payload.meta.datas[0].name, "sample.mp3");
  assert.equal(metaMessage.data.payload.query.data_id, "17896");
});

test("CVPC audio observer posts user meta snapshot with only safe user fields", function () {
  const observerModule = loadObserverModule();
  const harness = createWindowHarness();
  const observer = observerModule.createObserver({
    window: harness.window,
    location: {
      origin: "https://cvpc.data-baker.com",
      href: "https://cvpc.data-baker.com/app/editor/asr/",
    },
  });

  observer.observeResponse(
    "https://cvpc.data-baker.com/httpapi/user/meta",
    JSON.stringify({
      code: 0,
      data: {
        user_id: 9527,
        name: "柳州标注员",
        token: "should-not-be-forwarded",
        default_group_id: 1134,
      },
    })
  );

  const metaMessage = harness.postedMessages.find(function (item) {
    return item.data.type === META_TYPE;
  });

  assert.ok(metaMessage);
  assert.equal(metaMessage.data.payload.meta.user_id, 9527);
  assert.equal(metaMessage.data.payload.meta.name, "柳州标注员");
  assert.deepEqual(Object.keys(metaMessage.data.payload.meta).sort(), ["name", "user_id"]);
});

test("CVPC audio observer posts sanitized request auth snapshot for annotation api", function () {
  const observerModule = loadObserverModule();
  const harness = createWindowHarness();
  const observer = observerModule.createObserver({
    window: harness.window,
    location: {
      origin: "https://cvpc.data-baker.com",
      href: "https://cvpc.data-baker.com/app/editor/asr/",
    },
  });

  observer.observeRequestAuth(
    "https://cvpc.data-baker.com/httpapi/annotation/annos?project_id=1453&task_id=12099",
    {
      Authorization: "Bearer test-token",
      "Baker-Terminal": "group@1134",
      "Baker-Lang": "zh",
      "X-Ignored": "should-not-pass",
    }
  );

  const authMessage = harness.postedMessages.find(function (item) {
    return item.data.type === AUTH_TYPE;
  });

  assert.ok(authMessage);
  assert.equal(authMessage.origin, "https://cvpc.data-baker.com");
  assert.equal(authMessage.data.source, OBSERVER_SOURCE);
  assert.deepEqual(authMessage.data.payload.headers, {
    authorization: "Bearer test-token",
    "baker-terminal": "group@1134",
    "baker-lang": "zh",
  });
  assert.equal(authMessage.data.payload.path, "/httpapi/annotation/annos");
  assert.equal(authMessage.data.payload.query.project_id, "1453");
});

test("CVPC audio observer keeps the latest signed audio url for the same relative path", function () {
  const observerModule = loadObserverModule();
  const harness = createWindowHarness();
  const observer = observerModule.createObserver({
    window: harness.window,
    location: {
      origin: "https://cvpc.data-baker.com",
      href: "https://cvpc.data-baker.com/app/editor/asr/",
    },
  });

  observer.observeResponse(
    "https://cvpc.data-baker.com/httpapi/annotation/meta?project_id=1&task_id=2",
    JSON.stringify({
      code: 0,
      data: {
        datas: [
          {
            entry_id: 1,
            name: "sample.mp3",
            content: "databaker/data/sample.mp3",
          },
        ],
      },
    })
  );
  observer.observeAudioUrl(
    "https://databaker-cvpc.oss-cn-huhehaote.aliyuncs.com/databaker/data/sample.mp3?Expires=1&Signature=old"
  );
  observer.observeAudioUrl(
    "https://databaker-cvpc.oss-cn-huhehaote.aliyuncs.com/databaker/data/sample.mp3?Expires=2&Signature=new"
  );

  const snapshot = observer.getSnapshot();

  assert.equal(snapshot.mappings.length, 1);
  assert.match(snapshot.mappings[0].audioUrl, /Signature=new/);
  assert.equal(
    harness.postedMessages.filter(function (item) {
      return item.data.type === OBSERVER_TYPE;
    }).length,
    2
  );
});

test("CVPC audio observer applies structured field writes through matching component state slot", function () {
  const observerModule = loadObserverModule();
  const oldSerializedModelValue = JSON.stringify([{ type: "text", content: "旧文本" }]);
  const nextStructuredItems = [{ type: "single", id: "tag-1", content: "<Meaningless>" }];
  const nextSerializedModelValue = JSON.stringify(nextStructuredItems);
  const wrapper = {
    parentNode: null,
  };
  const textareaHost = {
    id: "textarea-test-1",
    parentNode: wrapper,
    attributes: {
      modelvalue: oldSerializedModelValue,
    },
    getAttribute: function (name) {
      return this.attributes[String(name || "")] || "";
    },
    setAttribute: function (name, value) {
      this.attributes[String(name || "")] = String(value || "");
    },
  };
  const component = {
    setupState: {
      modelvalue: oldSerializedModelValue,
    },
    data: {},
    ctx: {},
    proxy: {},
  };
  textareaHost.__vueParentComponent = component;

  const result = observerModule.applyStructuredFieldWriteRequest({
    document: {
      getElementById: function (id) {
        return id === "textarea-test-1" ? textareaHost : null;
      },
    },
    request: {
      textareaHostId: "textarea-test-1",
      oldSerializedModelValue: oldSerializedModelValue,
      serializedModelValue: nextSerializedModelValue,
      structuredItems: nextStructuredItems,
    },
  });

  assert.deepEqual(result, {
    ok: true,
    appliedBy: "setupState.modelvalue",
    message: "",
  });
  assert.equal(textareaHost.getAttribute("modelvalue"), nextSerializedModelValue);
  assert.equal(component.setupState.modelvalue, nextSerializedModelValue);
});

test("CVPC audio observer maps console printed audio url after meta is available", function () {
  const observerModule = loadObserverModule();
  const harness = createWindowHarness();
  const observer = observerModule.createObserver({
    window: harness.window,
    location: {
      origin: "https://cvpc.data-baker.com",
      href: "https://cvpc.data-baker.com/app/editor/asr/",
    },
  });

  observer.observeResponse(
    "https://cvpc.data-baker.com/httpapi/annotation/meta?project_id=1&task_id=2",
    JSON.stringify({
      code: 0,
      data: {
        datas: [
          {
            entry_id: 1,
            name: "sample.mp3",
            content: "databaker/data/sample.mp3",
          },
        ],
      },
    })
  );
  observer.observeConsoleArgs([
    "==========> gAudioUrl :",
    "https://databaker-cvpc.oss-cn-huhehaote.aliyuncs.com/databaker/data/sample.mp3?Signature=console",
  ]);

  const snapshot = observer.getSnapshot();

  assert.equal(snapshot.mappings.length, 1);
  assert.match(snapshot.mappings[0].audioUrl, /Signature=console/);
  assert.equal(snapshot.mappings[0].fileName, "sample.mp3");
});

test("CVPC audio observer maps console printed audio url before meta arrives", function () {
  const observerModule = loadObserverModule();
  const harness = createWindowHarness();
  const observer = observerModule.createObserver({
    window: harness.window,
    location: {
      origin: "https://cvpc.data-baker.com",
      href: "https://cvpc.data-baker.com/app/editor/asr/",
    },
  });

  observer.observeConsoleArgs([
    "audio_url:",
    "https://databaker-cvpc.oss-cn-huhehaote.aliyuncs.com/databaker/data/sample.mp3?Signature=pending-console",
  ]);
  observer.observeResponse(
    "https://cvpc.data-baker.com/httpapi/annotation/meta?project_id=1&task_id=2",
    JSON.stringify({
      code: 0,
      data: {
        datas: [
          {
            entry_id: 1,
            name: "sample.mp3",
            content: "databaker/data/sample.mp3",
          },
        ],
      },
    })
  );

  const snapshot = observer.getSnapshot();

  assert.equal(snapshot.mappings.length, 1);
  assert.match(snapshot.mappings[0].audioUrl, /Signature=pending-console/);
});

test("CVPC audio observer posts unmatched iframe audio candidate to top window", function () {
  const observerModule = loadObserverModule();
  const harness = createIframeWindowHarness();
  const observer = observerModule.createObserver({
    window: harness.window,
    location: {
      origin: "https://cvpc.data-baker.com",
      href: "https://cvpc.data-baker.com/app/xaudio/label/?id=249783",
    },
  });

  observer.observeConsoleArgs([
    "audio_url:",
    "https://databaker-cvpc.oss-cn-huhehaote.aliyuncs.com/databaker/data/17896/sample.mp3?Signature=iframe",
  ]);

  const mappingMessage = harness.postedMessages.find(function (item) {
    return item.data.type === OBSERVER_TYPE;
  });

  assert.ok(mappingMessage);
  assert.equal(mappingMessage.target, "parent");
  assert.equal(mappingMessage.origin, "https://cvpc.data-baker.com");
  assert.equal(mappingMessage.data.payload.fileName, "sample.mp3");
  assert.equal(mappingMessage.data.payload.relativePath, "databaker/data/17896/sample.mp3");
  assert.match(mappingMessage.data.payload.audioUrl, /Signature=iframe/);
});

test("CVPC audio observer does not wrap top window console methods on editor page", function () {
  const observerModule = loadObserverModule();
  const harness = createWindowHarness();
  const nativeInfo = harness.window.console.info;
  const nativeLog = harness.window.console.log;
  const nativeDebug = harness.window.console.debug;
  const observer = observerModule.createObserver({
    window: harness.window,
    location: {
      origin: "https://cvpc.data-baker.com",
      href: "https://cvpc.data-baker.com/app/editor/asr/",
    },
  });

  observer.install();

  assert.equal(harness.window.console.info, nativeInfo);
  assert.equal(harness.window.console.log, nativeLog);
  assert.equal(harness.window.console.debug, nativeDebug);
});

test("CVPC audio observer installed console wrapper captures info audio url inside xaudio iframe", function () {
  const observerModule = loadObserverModule();
  const harness = createIframeWindowHarness();
  const observer = observerModule.createObserver({
    window: harness.window,
    location: {
      origin: "https://cvpc.data-baker.com",
      href: "https://cvpc.data-baker.com/app/xaudio/label/?id=249783",
    },
  });

  observer.install();
  harness.window.console.info(
    "audio_url:",
    "https://databaker-cvpc.oss-cn-huhehaote.aliyuncs.com/databaker/data/sample.mp3?Signature=info-console"
  );

  const mappingMessage = harness.postedMessages.find(function (item) {
    return item.data.type === OBSERVER_TYPE;
  });

  assert.ok(mappingMessage);
  assert.equal(mappingMessage.target, "parent");
  assert.match(mappingMessage.data.payload.audioUrl, /Signature=info-console/);
});

test("CVPC audio observer does not wrap console warn", function () {
  const observerModule = loadObserverModule();
  const harness = createWindowHarness();
  const nativeWarn = harness.window.console.warn;
  const observer = observerModule.createObserver({
    window: harness.window,
    location: {
      origin: "https://cvpc.data-baker.com",
      href: "https://cvpc.data-baker.com/app/editor/asr/",
    },
  });

  observer.install();

  assert.equal(harness.window.console.warn, nativeWarn);
});

test("CVPC audio observer ignores unmatched or non-audio urls", function () {
  const observerModule = loadObserverModule();
  const harness = createWindowHarness();
  const observer = observerModule.createObserver({
    window: harness.window,
    location: {
      origin: "https://cvpc.data-baker.com",
      href: "https://cvpc.data-baker.com/app/editor/asr/",
    },
  });

  observer.observeResponse(
    "https://cvpc.data-baker.com/httpapi/annotation/meta?project_id=1&task_id=2",
    JSON.stringify({
      code: 0,
      data: {
        datas: [
          {
            entry_id: 1,
            name: "sample.mp3",
            content: "databaker/data/sample.mp3",
          },
        ],
      },
    })
  );
  observer.observeAudioUrl("https://cvpc.data-baker.com/httpapi/platform_setting/view");
  observer.observeAudioUrl("https://example.com/static/app.js");
  observer.observeAudioUrl("https://oss.example.com/another-file.wav?Signature=no-match");

  const snapshot = observer.getSnapshot();

  assert.equal(snapshot.mappings.length, 0);
  assert.equal(
    harness.postedMessages.filter(function (item) {
      return item.data.type === OBSERVER_TYPE;
    }).length,
    0
  );
});
