(function () {
  const SOURCE = "ASR_EDGE_BYTEDANCE_AIDP_OBSERVER";
  const RECEIVE_TYPE = "BYTEDANCE_AIDP_RECEIVE_SNAPSHOT";
  const SUBMIT_TYPE = "BYTEDANCE_AIDP_SUBMIT_SNAPSHOT";
  const SEARCH_ITEM_TYPE = "BYTEDANCE_AIDP_SEARCH_ITEM_SNAPSHOT";
  const SEARCH_MODIFY_ITEM_TYPE = "BYTEDANCE_AIDP_SEARCH_MODIFY_ITEM_SNAPSHOT";
  const SEARCH_MODIFY_ITEM_REPLAY_REQUEST_TYPE =
    "BYTEDANCE_AIDP_SEARCH_MODIFY_ITEM_SNAPSHOT_REQUEST";
  const WORK_ITEM_TYPE = "BYTEDANCE_AIDP_WORK_ITEM_SNAPSHOT";
  const WORK_ITEM_REPLAY_REQUEST_TYPE = "BYTEDANCE_AIDP_WORK_ITEM_SNAPSHOT_REQUEST";
  const NETWORK_ACTIVITY_TYPE = "BYTEDANCE_AIDP_NETWORK_ACTIVITY";
  const RECEIVE_SNAPSHOT_VERSION = 1;
  const RECEIVE_PATH = "/api/dispatch/Receive";
  const SUBMIT_PATH = "/api/dispatch/SubmitTempItemAnswer";
  const SEARCH_ITEM_PATH = "/dispatcher/search_item/category";
  const SEARCH_MODIFY_ITEM_PATH = "/api/dispatch/SearchModifyItem";
  const WORK_ITEM_PATH = "/api/dispatch/GetWorkItem";
  const ALLOWED_SUBMIT_HEADERS = ["accept", "content-type", "x-secsdk-csrf-token"];

  function normalizeText(value) {
    return String(value || "").trim();
  }

  function getUrl(rawUrl, locationLike) {
    try {
      return new URL(String(rawUrl || ""), locationLike?.href || "https://aidp.bytedance.com/");
    } catch (_error) {
      return null;
    }
  }

  function isReceiveUrl(rawUrl, locationLike) {
    return getUrl(rawUrl, locationLike)?.pathname === RECEIVE_PATH;
  }

  function isSubmitUrl(rawUrl, locationLike) {
    return getUrl(rawUrl, locationLike)?.pathname === SUBMIT_PATH;
  }

  function isSearchItemUrl(rawUrl, locationLike) {
    return getUrl(rawUrl, locationLike)?.pathname === SEARCH_ITEM_PATH;
  }

  function isSearchModifyItemUrl(rawUrl, locationLike) {
    return getUrl(rawUrl, locationLike)?.pathname === SEARCH_MODIFY_ITEM_PATH;
  }

  function isWorkItemUrl(rawUrl, locationLike) {
    return getUrl(rawUrl, locationLike)?.pathname === WORK_ITEM_PATH;
  }

  function readHeaderEntries(source) {
    const result = [];
    if (!source) {
      return result;
    }
    if (typeof source.forEach === "function") {
      try {
        source.forEach(function (value, key) {
          result.push([key, value]);
        });
        return result;
      } catch (_error) {
        // Ignore unsupported Headers-like objects.
      }
    }
    if (Array.isArray(source)) {
      source.forEach(function (item) {
        if (Array.isArray(item) && item.length >= 2) {
          result.push([item[0], item[1]]);
        }
      });
      return result;
    }
    if (typeof source === "object") {
      Object.keys(source).forEach(function (key) {
        result.push([key, source[key]]);
      });
    }
    return result;
  }

  function sanitizeSubmitHeaders(headers) {
    const result = {};
    readHeaderEntries(headers).forEach(function (entry) {
      const name = normalizeText(entry[0]).toLowerCase();
      if (ALLOWED_SUBMIT_HEADERS.indexOf(name) < 0) {
        return;
      }
      const value = normalizeText(entry[1]);
      if (!value) {
        return;
      }
      result[name] = value;
    });
    if (!result["content-type"]) {
      result["content-type"] = "application/json";
    }
    return result;
  }

  function mergeHeaderSources(left, right) {
    const merged = {};
    readHeaderEntries(left).forEach(function (entry) {
      merged[String(entry[0] || "")] = entry[1];
    });
    readHeaderEntries(right).forEach(function (entry) {
      merged[String(entry[0] || "")] = entry[1];
    });
    return merged;
  }

  function parseJsonSafely(value) {
    if (!value) {
      return null;
    }
    if (typeof value === "object") {
      return value;
    }
    try {
      return JSON.parse(String(value));
    } catch (_error) {
      return null;
    }
  }

  function stringifyBodyCandidate(value) {
    if (typeof value === "string") {
      return value;
    }
    if (value === null || value === undefined) {
      return "";
    }
    if (typeof value === "object") {
      try {
        return JSON.stringify(value);
      } catch (_error) {
        return "";
      }
    }
    return String(value || "");
  }

  function parseSearchItemSnapshots(value) {
    const response = parseJsonSafely(value) || {};
    const items = Array.isArray(response.Data) ? response.Data : [];
    return items
      .map(function (item) {
        const content =
          item && typeof item.Content === "string"
            ? parseJsonSafely(item.Content) || {}
            : {};
        return {
          sourceItemId: normalizeText(item?.ItemID),
          referenceText: normalizeText(content.asr_text),
          audioUrl: normalizeText(content.audio),
          videoUrl: normalizeText(content.video),
        };
      })
      .filter(function (item) {
        return Boolean(item.sourceItemId);
      });
  }

  function sanitizeSearchModifyItemSnapshot(requestBody, responseValue, capturedAt) {
    const request = parseJsonSafely(requestBody) || {};
    const filter = request?.Filter && typeof request.Filter === "object" ? request.Filter : {};
    const pageRequest =
      request?.PageRequest && typeof request.PageRequest === "object"
        ? request.PageRequest
        : {};
    const response = parseJsonSafely(responseValue) || {};
    const items = (Array.isArray(response.Items) ? response.Items : [])
      .map(function (item) {
        const content =
          item && typeof item.Content === "string"
            ? parseJsonSafely(item.Content)
            : null;
        if (!content || typeof content !== "object") {
          return null;
        }
        const sanitized = {
          sourceItemId: normalizeText(item?.ItemID),
          taskId: normalizeText(item?.TaskID),
          nodeId: Number(item?.NodeID),
          referenceText: normalizeText(content.asr_text),
          audioUrl: normalizeText(content.audio),
          videoUrl: normalizeText(content.video),
        };
        if (
          !sanitized.sourceItemId ||
          (!sanitized.referenceText && !sanitized.audioUrl && !sanitized.videoUrl)
        ) {
          return null;
        }
        return sanitized;
      })
      .filter(Boolean);
    return {
      taskId: normalizeText(filter.TaskID),
      filterNodeId: Number(filter.NodeID),
      direction: Number(filter.Direction),
      pageNo: Number(pageRequest.PageNo),
      pageSize: Number(pageRequest.PageSize),
      capturedAt: Number(capturedAt),
      items: items,
    };
  }

  function sanitizeWorkItemSnapshots(value) {
    const response = parseJsonSafely(value);
    const items = Array.isArray(response)
      ? response
      : Array.isArray(response?.Items)
        ? response.Items
        : [];
    return items
      .map(function (entry) {
        const item = entry?.Item && typeof entry.Item === "object" ? entry.Item : {};
        const answer = typeof entry?.Answer === "string" ? entry.Answer : "";
        const content = typeof item.Content === "string" ? item.Content : "";
        const itemId = normalizeText(item.ItemID);
        if (!itemId || !answer) {
          return null;
        }
        return {
          Item: {
            ItemID: itemId,
            Content: content,
          },
          Answer: answer,
        };
      })
      .filter(Boolean);
  }

  function sanitizeReceiveEntry(entry) {
    const item = entry?.Item && typeof entry.Item === "object" ? entry.Item : {};
    const tempAnswer =
      entry?.TempAnswer && typeof entry.TempAnswer === "object" ? entry.TempAnswer : {};
    const itemId = normalizeText(item.ItemID);
    const content = typeof item.Content === "string" ? item.Content : "";
    const tempAnswerContent =
      typeof tempAnswer.Content === "string" ? tempAnswer.Content : "";
    if (!itemId || !content || !tempAnswerContent) {
      return null;
    }
    return {
      Item: {
        ItemID: itemId,
        Content: content,
      },
      TempAnswer: {
        Content: tempAnswerContent,
      },
    };
  }

  function sanitizeReceiveSnapshots(value) {
    const response = parseJsonSafely(value) || {};
    const sanitizeItems = function (items) {
      return (Array.isArray(items) ? items : []).map(sanitizeReceiveEntry).filter(Boolean);
    };
    if (Array.isArray(response?.Items)) {
      return { Items: sanitizeItems(response.Items) };
    }
    if (Array.isArray(response?.Data?.Items)) {
      return { Data: { Items: sanitizeItems(response.Data.Items) } };
    }
    if (Array.isArray(response?.data?.items)) {
      return { data: { items: sanitizeItems(response.data.items) } };
    }
    return { Items: [] };
  }

  function postMessage(windowLike, locationLike, type, payload) {
    if (!windowLike || typeof windowLike.postMessage !== "function") {
      return;
    }
    windowLike.postMessage(
      {
        source: SOURCE,
        type: type,
        payload: payload,
      },
      locationLike?.origin || "*"
    );
  }

  async function readFetchBodyText(input, init) {
    if (typeof init?.body === "string") {
      return init.body;
    }
    if (init?.body && typeof init.body === "object") {
      return stringifyBodyCandidate(init.body);
    }
    if (input && typeof input.clone === "function") {
      try {
        return await input.clone().text();
      } catch (_error) {
        return "";
      }
    }
    return "";
  }

  function createObserver(options) {
    const deps = options && typeof options === "object" ? options : {};
    const windowLike = deps.window || globalThis.window || globalThis;
    const locationLike = deps.location || windowLike.location || globalThis.location || {};
    const now = typeof deps.now === "function" ? deps.now : Date.now;
    let installed = false;
    let pendingNetworkRequestCount = 0;
    let networkActivitySequence = 0;
    let latestWorkItemResponse = null;
    let latestWorkItemCapturedAt = Number.NaN;
    let latestSearchModifyItemSnapshot = null;

    function notifyReceive(payload) {
      postMessage(windowLike, locationLike, RECEIVE_TYPE, {
        snapshotVersion: RECEIVE_SNAPSHOT_VERSION,
        response: sanitizeReceiveSnapshots(payload),
      });
    }

    function notifySubmit(rawUrl, headers, body) {
      postMessage(windowLike, locationLike, SUBMIT_TYPE, {
        url: getUrl(rawUrl, locationLike)?.href || String(rawUrl || ""),
        headers: sanitizeSubmitHeaders(headers),
        body: parseJsonSafely(body) || {},
      });
    }

    function notifySearchItem(payload) {
      postMessage(
        windowLike,
        locationLike,
        SEARCH_ITEM_TYPE,
        {
          items: parseSearchItemSnapshots(payload),
        }
      );
    }

    function notifySearchModifyItem(requestBody, responseValue) {
      latestSearchModifyItemSnapshot = sanitizeSearchModifyItemSnapshot(
        requestBody,
        responseValue,
        now()
      );
      postMessage(
        windowLike,
        locationLike,
        SEARCH_MODIFY_ITEM_TYPE,
        latestSearchModifyItemSnapshot
      );
    }

    function notifyWorkItem(payload) {
      latestWorkItemResponse = sanitizeWorkItemSnapshots(payload);
      latestWorkItemCapturedAt = Number(now());
      postMessage(windowLike, locationLike, WORK_ITEM_TYPE, {
        capturedAt: latestWorkItemCapturedAt,
        response: latestWorkItemResponse,
      });
    }

    function replayLatestWorkItem(event) {
      const data = event?.data && typeof event.data === "object" ? event.data : {};
      if (
        data.source !== SOURCE ||
        data.type !== WORK_ITEM_REPLAY_REQUEST_TYPE ||
        !Array.isArray(latestWorkItemResponse)
      ) {
        return;
      }
      const origin = normalizeText(event?.origin);
      if (origin && origin !== normalizeText(locationLike?.origin)) {
        return;
      }
      postMessage(windowLike, locationLike, WORK_ITEM_TYPE, {
        capturedAt: latestWorkItemCapturedAt,
        response: latestWorkItemResponse,
      });
    }

    function replayLatestSearchModifyItem(event) {
      const data = event?.data && typeof event.data === "object" ? event.data : {};
      if (
        data.source !== SOURCE ||
        data.type !== SEARCH_MODIFY_ITEM_REPLAY_REQUEST_TYPE ||
        !latestSearchModifyItemSnapshot
      ) {
        return;
      }
      const origin = normalizeText(event?.origin);
      if (origin && origin !== normalizeText(locationLike?.origin)) {
        return;
      }
      postMessage(
        windowLike,
        locationLike,
        SEARCH_MODIFY_ITEM_TYPE,
        latestSearchModifyItemSnapshot
      );
    }

    function replayLatestSnapshot(event) {
      replayLatestWorkItem(event);
      replayLatestSearchModifyItem(event);
    }

    function notifyNetworkActivity() {
      networkActivitySequence += 1;
      postMessage(windowLike, locationLike, NETWORK_ACTIVITY_TYPE, {
        pendingCount: pendingNetworkRequestCount,
        activitySequence: networkActivitySequence,
      });
    }

    function beginNetworkActivity() {
      let settled = false;
      pendingNetworkRequestCount += 1;
      notifyNetworkActivity();
      return function settleNetworkActivity() {
        if (settled) {
          return;
        }
        settled = true;
        pendingNetworkRequestCount = Math.max(0, pendingNetworkRequestCount - 1);
        notifyNetworkActivity();
      };
    }

    function installFetchObserver() {
      const nativeFetch = windowLike.fetch;
      if (typeof nativeFetch !== "function") {
        return;
      }
      windowLike.fetch = function () {
        const args = Array.from(arguments);
        const input = args[0];
        const init = args[1];
        const rawUrl =
          typeof input === "string"
            ? input
            : input && typeof input.url === "string"
              ? input.url
              : "";
        if (isSubmitUrl(rawUrl, locationLike)) {
          void readFetchBodyText(input, init).then(function (bodyText) {
            notifySubmit(rawUrl, mergeHeaderSources(input?.headers, init?.headers), bodyText);
          });
        }
        const searchModifyItemBodyPromise = isSearchModifyItemUrl(rawUrl, locationLike)
          ? readFetchBodyText(input, init)
          : null;
        const settleNetworkActivity = beginNetworkActivity();
        let request;
        try {
          request = nativeFetch.apply(this, args);
        } catch (error) {
          settleNetworkActivity();
          throw error;
        }
        Promise.resolve(request).then(
          function (response) {
            settleNetworkActivity();
            const receiveRequest = isReceiveUrl(rawUrl, locationLike);
            const searchItemRequest = isSearchItemUrl(rawUrl, locationLike);
            const searchModifyItemRequest = isSearchModifyItemUrl(rawUrl, locationLike);
            const workItemRequest = isWorkItemUrl(rawUrl, locationLike);
            if (
              !receiveRequest &&
              !searchItemRequest &&
              !searchModifyItemRequest &&
              !workItemRequest
            ) {
              return;
            }
            try {
              response
                .clone()
                .text()
                .then(function (text) {
                  const payload = parseJsonSafely(text);
                  if (receiveRequest && payload) {
                    notifyReceive(payload);
                  } else if (workItemRequest && payload) {
                    notifyWorkItem(payload);
                  } else if (searchItemRequest) {
                    notifySearchItem(text);
                  } else if (searchModifyItemRequest) {
                    Promise.resolve(searchModifyItemBodyPromise).then(function (requestBody) {
                      notifySearchModifyItem(requestBody, text);
                    });
                  }
                })
                .catch(function () {});
            } catch (_error) {
              // Keep page behavior unchanged if response cloning fails.
            }
          },
          function () {
            settleNetworkActivity();
          }
        );
        return request;
      };
    }

    function installXhrObserver() {
      const NativeXhr = windowLike.XMLHttpRequest;
      if (typeof NativeXhr !== "function") {
        return;
      }
      const nativeOpen = NativeXhr.prototype.open;
      const nativeSend = NativeXhr.prototype.send;
      const nativeSetRequestHeader = NativeXhr.prototype.setRequestHeader;
      if (
        typeof nativeOpen !== "function" ||
        typeof nativeSend !== "function" ||
        typeof nativeSetRequestHeader !== "function"
      ) {
        return;
      }

      NativeXhr.prototype.open = function (method, url) {
        this.__ascAidpRawUrl = String(url || "");
        this.__ascAidpHeaders = {};
        return nativeOpen.apply(this, arguments);
      };

      NativeXhr.prototype.setRequestHeader = function (name, value) {
        if (!this.__ascAidpHeaders || typeof this.__ascAidpHeaders !== "object") {
          this.__ascAidpHeaders = {};
        }
        this.__ascAidpHeaders[String(name || "")] = value;
        return nativeSetRequestHeader.apply(this, arguments);
      };

      NativeXhr.prototype.send = function (body) {
        const xhr = this;
        const rawUrl = xhr.__ascAidpRawUrl || "";
        const requestBody = stringifyBodyCandidate(body);
        const settleNetworkActivity = beginNetworkActivity();
        if (typeof xhr.addEventListener === "function") {
          xhr.addEventListener("loadend", settleNetworkActivity);
        }
        if (isSubmitUrl(rawUrl, locationLike)) {
          notifySubmit(rawUrl, xhr.__ascAidpHeaders, stringifyBodyCandidate(body));
        }
        if (
          (isReceiveUrl(rawUrl, locationLike) ||
            isSearchItemUrl(rawUrl, locationLike) ||
            isSearchModifyItemUrl(rawUrl, locationLike) ||
            isWorkItemUrl(rawUrl, locationLike)) &&
          typeof xhr.addEventListener === "function"
        ) {
          xhr.addEventListener("load", function () {
            const payload = parseJsonSafely(xhr.responseText);
            if (isReceiveUrl(rawUrl, locationLike) && payload) {
              notifyReceive(payload);
            } else if (isWorkItemUrl(rawUrl, locationLike) && payload) {
              notifyWorkItem(payload);
            } else if (isSearchItemUrl(rawUrl, locationLike)) {
              notifySearchItem(xhr.responseText);
            } else if (isSearchModifyItemUrl(rawUrl, locationLike)) {
              notifySearchModifyItem(requestBody, xhr.responseText);
            }
          });
        }
        try {
          return nativeSend.apply(this, arguments);
        } catch (error) {
          settleNetworkActivity();
          throw error;
        }
      };
    }

    function install() {
      if (installed) {
        return;
      }
      installed = true;
      if (typeof windowLike.addEventListener === "function") {
        windowLike.addEventListener("message", replayLatestSnapshot);
      }
      installFetchObserver();
      installXhrObserver();
    }

    return {
      install,
    };
  }

  const api = {
    createObserver,
    constants: {
      SOURCE: SOURCE,
      RECEIVE_TYPE: RECEIVE_TYPE,
      SUBMIT_TYPE: SUBMIT_TYPE,
      SEARCH_ITEM_TYPE: SEARCH_ITEM_TYPE,
      SEARCH_MODIFY_ITEM_TYPE: SEARCH_MODIFY_ITEM_TYPE,
      SEARCH_MODIFY_ITEM_REPLAY_REQUEST_TYPE: SEARCH_MODIFY_ITEM_REPLAY_REQUEST_TYPE,
      WORK_ITEM_TYPE: WORK_ITEM_TYPE,
      NETWORK_ACTIVITY_TYPE: NETWORK_ACTIVITY_TYPE,
    },
  };

  globalThis.ASREdgeBytedanceAidpNetworkObserverPage = api;

  if (typeof module !== "undefined" && module.exports) {
    module.exports = api;
  }

  if (typeof window !== "undefined") {
    const legacyFlag = "__ASREdgeBytedanceAidpNetworkObserverInstalled";
    const workItemObserverFlag = "__ASREdgeBytedanceAidpWorkItemObserverInstalled";
    if (!window[workItemObserverFlag]) {
      window[legacyFlag] = true;
      window[workItemObserverFlag] = true;
      createObserver({ window, location: window.location }).install();
    }
  }
})();
