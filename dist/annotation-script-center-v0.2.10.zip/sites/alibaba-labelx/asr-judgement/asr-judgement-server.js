(function () {
  const LOG_PREFIX = "[ASR Edge][judgement-stats]";
  const DEFAULT_PAGE_SIZE = 400;
  const DEFAULT_HOME_PAGE_SIZE = 100;
  const DEFAULT_UPLOAD_PATH = "/api/alibaba-labelx/asr-judgement/statistics/upload";
  const DEFAULT_SERVER_UPLOAD_ENDPOINT =
    "https://script.xiangtianzhen.store" + DEFAULT_UPLOAD_PATH;
  const DEFAULT_UPLOAD_TIMES = ["10:00", "16:00"];
  const DEFAULT_UPLOAD_JITTER_MINUTES = 10;
  const JUDGEMENT_LABEL_MODEL = "vote";
  const TRANSCRIPTION_LABEL_MODEL = "single";
  const JUDGEMENT_TASK_SIZE = 400;
  const TRANSCRIPTION_TASK_SIZE = 50;
  const HOME_TASK_KINDS = [
    {
      key: "label",
      role: "label",
      route: "/corpora/labeling/labelingtask",
      listType: "label",
      taskType: "label",
      label: "标注",
    },
    {
      key: "check",
      role: "audit",
      route: "/corpora/labeling/checktask",
      listType: "check",
      taskType: "check",
      label: "审核",
    },
  ];
  const CSV_COLUMNS = [
    "任务名称",
    "任务ID",
    "标注员1子任务ID",
    "标注员2子任务ID",
    "标注员3子任务ID",
    "审核子任务ID",
    "分包ID",
    "题数",
    "有效时长(秒)",
    "标注员1",
    "标注员2",
    "标注员3",
    "审核员",
    "标注员1领取时间",
    "标注员1提交时间",
    "标注员2领取时间",
    "标注员2提交时间",
    "标注员3领取时间",
    "标注员3提交时间",
    "审核领取时间",
    "审核提交时间",
    "标注员1是否完成",
    "标注员2是否完成",
    "标注员3是否完成",
    "审核是否完成",
  ];

  function clone(value) {
    return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
  }

  function normalizeUrlParam(value) {
    try {
      return decodeURIComponent(String(value || "")).trim();
    } catch (error) {
      return String(value || "").trim();
    }
  }

  function getUrlParams() {
    const params = new URLSearchParams(location.search || "");
    return {
      projectId: normalizeUrlParam(params.get("projectId") || ""),
      subTaskId: normalizeUrlParam(params.get("subTaskId") || ""),
      missionType: normalizeUrlParam(params.get("missionType") || ""),
    };
  }

  function trimSlash(value) {
    return String(value || "").replace(/\/+$/, "");
  }

  function normalizeEndpoint(value) {
    const text = String(value || "").trim();
    if (!text) {
      return "";
    }

    try {
      return new URL(text, location.origin).toString();
    } catch (error) {
      return "";
    }
  }

  function summarizeUploadResponseBody(body) {
    if (!body) {
      return "";
    }

    const text =
      typeof body === "string"
        ? body
        : body.message
          ? body.message
          : JSON.stringify(body);
    return String(text || "").replace(/\s+/g, " ").trim().slice(0, 300);
  }

  function getEndpointLabel(endpoint) {
    try {
      const url = new URL(endpoint);
      return url.origin + url.pathname;
    } catch (error) {
      return String(endpoint || "").trim();
    }
  }

  function resolveUploadEndpoint(config) {
    const explicitEndpoint = normalizeEndpoint(config?.statsUploadEndpoint);
    if (explicitEndpoint) {
      return explicitEndpoint;
    }

    const server = config?.legacyServer || {};
    const baseUrl = server.useDebugApiBaseUrl === true ? server.debugApiBaseUrl : server.apiBaseUrl;
    const normalizedBaseUrl = normalizeEndpoint(baseUrl);
    return normalizedBaseUrl ? trimSlash(normalizedBaseUrl) + DEFAULT_UPLOAD_PATH : DEFAULT_SERVER_UPLOAD_ENDPOINT;
  }

  function resolveScheduleEndpoint(config) {
    const uploadEndpoint = resolveUploadEndpoint(config);
    if (!uploadEndpoint) {
      return "";
    }

    try {
      const url = new URL(uploadEndpoint);
      url.searchParams.set("purpose", "schedule");
      return url.toString();
    } catch (error) {
      return "";
    }
  }

  function normalizeTimeList(value) {
    const source = Array.isArray(value)
      ? value
      : typeof value === "string"
        ? value.split(/[,，\n]/)
        : DEFAULT_UPLOAD_TIMES;
    const result = [];

    source.forEach(function (item) {
      const text = String(item || "").trim();
      const match = text.match(/^([01]?\d|2[0-3]):([0-5]\d)$/);
      if (!match) {
        return;
      }

      const normalized = String(Number(match[1])).padStart(2, "0") + ":" + match[2];
      if (result.indexOf(normalized) < 0) {
        result.push(normalized);
      }
    });

    return result.length > 0 ? result : DEFAULT_UPLOAD_TIMES.slice();
  }

  function parseScheduleResponse(body, fallbackConfig) {
    const data = body && typeof body === "object" ? body.data || body : {};
    const times = normalizeTimeList(
      data.times || data.uploadTimes || data.scheduleTimes || fallbackConfig.statsUploadTimes
    );
    const jitterMinutes = Number(data.jitterMinutes || data.randomDelayMinutes);

    return {
      enabled: data.enabled !== false,
      times: times,
      jitterMinutes: Number.isFinite(jitterMinutes)
        ? Math.max(0, Math.min(120, jitterMinutes))
        : Math.max(
            0,
            Math.min(
              120,
              Number(fallbackConfig.statsUploadJitterMinutes) || DEFAULT_UPLOAD_JITTER_MINUTES
            )
          ),
      source: body && typeof body === "object" ? "remote" : "local",
      fetchedAt: new Date().toISOString(),
    };
  }

  function buildSubtaskDataUrl(subTaskId, pageSize, page) {
    const url = new URL(
      "/api/v1/label/center/subTask/" + encodeURIComponent(subTaskId) + "/data",
      location.origin
    );
    url.searchParams.set("page", String(page || 1));
    url.searchParams.set("pageSize", String(pageSize || DEFAULT_PAGE_SIZE));
    url.searchParams.set("filterPassedVote", "false");
    url.searchParams.set(
      "filter",
      JSON.stringify({
        questions: [],
        dataStatus: "ALL",
        questionsQueryConditions: "AND",
      })
    );
    url.searchParams.set("_", String(Date.now()));
    return url;
  }

  function getHomeTaskKind(pathname) {
    const path = String(pathname || location.pathname || "").toLowerCase();
    return (
      HOME_TASK_KINDS.find(function (kind) {
        return path.indexOf(kind.route) >= 0;
      }) || null
    );
  }

  function getHomeTaskKindsToFetch() {
    return HOME_TASK_KINDS.slice();
  }

  function buildHomeTasksUrl(projectId, page, pageSize, kind) {
    const url = new URL("/api/v1/label/center/tasks", location.origin);
    url.searchParams.set("subTaskType", String(kind?.taskType || "label"));
    url.searchParams.set("keyword", "");
    url.searchParams.set("appId", String(projectId || ""));
    url.searchParams.set("page", String(page || 1));
    url.searchParams.set("pageSize", String(pageSize || DEFAULT_HOME_PAGE_SIZE));
    url.searchParams.set("_", String(Date.now()));
    return url;
  }

  function buildHomeSubTasksUrl(projectId, finished, page, pageSize, kind) {
    const url = new URL("/api/v1/label/center/subTasks", location.origin);
    url.searchParams.set("type", String(kind?.listType || "label"));
    url.searchParams.set("keyword", "");
    url.searchParams.set("appId", String(projectId || ""));
    url.searchParams.set("finished", finished ? "true" : "false");
    url.searchParams.set("page", String(page || 1));
    url.searchParams.set("pageSize", String(pageSize || DEFAULT_HOME_PAGE_SIZE));
    url.searchParams.set("_", String(Date.now()));
    return url;
  }

  async function fetchJson(url, init) {
    const response = await fetch(url.toString(), init || {});
    if (!response.ok) {
      throw new Error("请求失败：" + String(response.status));
    }

    const body = await response.json();
    if (body?.success === false || (body?.code !== undefined && body.code !== 0)) {
      throw new Error(body?.message || "业务响应失败。");
    }

    return body;
  }

  async function fetchSubtaskData(subTaskId) {
    const body = await fetchJson(buildSubtaskDataUrl(subTaskId, DEFAULT_PAGE_SIZE, 1), {
      credentials: "include",
      cache: "no-store",
      headers: {
        Accept: "application/json, text/plain, */*",
      },
    });
    return body?.data || {};
  }

  function normalizeListPage(body) {
    const data = body?.data && typeof body.data === "object" ? body.data : {};
    const list = Array.isArray(data.data) ? data.data : Array.isArray(data.list) ? data.list : [];
    const recordCount = Number(data.recordCount ?? data.total ?? list.length);
    return {
      list: list,
      recordCount: Number.isFinite(recordCount) && recordCount >= 0 ? recordCount : list.length,
    };
  }

  async function fetchPagedList(buildUrl, pageSize) {
    const normalizedPageSize = pageSize || DEFAULT_HOME_PAGE_SIZE;
    const result = [];
    let page = 1;
    let recordCount = 0;

    while (page <= 50) {
      const body = await fetchJson(buildUrl(page, normalizedPageSize), {
        credentials: "include",
        cache: "no-store",
        headers: {
          Accept: "application/json, text/plain, */*",
        },
      });
      const normalized = normalizeListPage(body);
      recordCount = normalized.recordCount;
      result.push.apply(result, normalized.list);
      if (result.length >= recordCount || normalized.list.length < normalizedPageSize) {
        break;
      }
      page += 1;
    }

    return {
      list: result,
      recordCount: recordCount || result.length,
    };
  }

  async function fetchHomeTasks(projectId, kind) {
    return fetchPagedList(function (page, pageSize) {
      return buildHomeTasksUrl(projectId, page, pageSize, kind);
    }, DEFAULT_HOME_PAGE_SIZE);
  }

  async function fetchHomeSubTasks(projectId, finished, kind) {
    return fetchPagedList(function (page, pageSize) {
      return buildHomeSubTasksUrl(projectId, finished, page, pageSize, kind);
    }, DEFAULT_HOME_PAGE_SIZE);
  }

  function sumDurationSeconds(dataList) {
    const total = (Array.isArray(dataList) ? dataList : []).reduce(function (sum, item) {
      const duration = Number(item?.data?.duration);
      return Number.isFinite(duration) && duration >= 0 ? sum + duration : sum;
    }, 0);
    return roundDurationSeconds(total);
  }

  function roundDurationSeconds(totalSeconds) {
    const seconds = Math.max(0, Number(totalSeconds) || 0);
    return Math.round((seconds + Number.EPSILON) * 10000) / 10000;
  }

  function formatDurationForCsv(totalSeconds) {
    return roundDurationSeconds(totalSeconds).toFixed(4);
  }

  function getFirstRecordValue(records, keys) {
    const recordList = Array.isArray(records) ? records : [records];
    for (let recordIndex = 0; recordIndex < recordList.length; recordIndex += 1) {
      const record = recordList[recordIndex];
      if (!record || typeof record !== "object") {
        continue;
      }

      for (let keyIndex = 0; keyIndex < keys.length; keyIndex += 1) {
        const value = record[keys[keyIndex]];
        if (value !== undefined && value !== null && String(value).trim() !== "") {
          return value;
        }
      }
    }

    return "";
  }

  function normalizeTaskName(value) {
    return String(value || "").replace(/\s+/g, "").toLowerCase();
  }

  function getTaskSizeFromRecords(records) {
    const size = Number(getFirstRecordValue(records, ["size", "total", "itemCount"]));
    return Number.isFinite(size) ? size : null;
  }

  function hasJudgementTaskName(name) {
    const normalized = normalizeTaskName(name);
    return (
      normalized.indexOf("asr更优结果判断") >= 0 ||
      normalized.indexOf("asr更优") >= 0 ||
      normalized.indexOf("更优结果判断") >= 0
    );
  }

  function hasTranscriptionTaskName(name) {
    const normalized = normalizeTaskName(name);
    return normalized.indexOf("中文普通话asr任务") >= 0;
  }

  function getTaskIdentityRecords(record, linkedTask) {
    return [record || {}, linkedTask || {}];
  }

  function isKnownTranscriptionTaskRecord(record, linkedTask) {
    const records = getTaskIdentityRecords(record, linkedTask);
    const labelModel = String(getFirstRecordValue(records, ["labelModel"]) || "").toLowerCase();
    const taskName = getFirstRecordValue(records, ["taskName", "name"]);
    const size = getTaskSizeFromRecords(records);

    return (
      labelModel === TRANSCRIPTION_LABEL_MODEL ||
      hasTranscriptionTaskName(taskName) ||
      size === TRANSCRIPTION_TASK_SIZE
    );
  }

  function isAsrJudgementTaskRecord(record, linkedTask) {
    const records = getTaskIdentityRecords(record, linkedTask);
    const labelModel = String(getFirstRecordValue(records, ["labelModel"]) || "").toLowerCase();
    const taskName = getFirstRecordValue(records, ["taskName", "name"]);
    const size = getTaskSizeFromRecords(records);

    if (labelModel === JUDGEMENT_LABEL_MODEL) {
      return true;
    }
    if (isKnownTranscriptionTaskRecord(record, linkedTask)) {
      return false;
    }

    const judgementName = hasJudgementTaskName(taskName);
    if (judgementName) {
      return size === null || size === JUDGEMENT_TASK_SIZE;
    }

    return size === JUDGEMENT_TASK_SIZE;
  }

  function isIgnoredUserText(text) {
    return (
      !text ||
      text === "填写问卷" ||
      text === "退出登录" ||
      text === "标注中心" ||
      text === "帮助文档" ||
      text === "智能标注" ||
      text.indexOf("总时长") >= 0 ||
      text.indexOf("上传统计") >= 0
    );
  }

  function getCurrentUserText() {
    const candidates = Array.from(
      document.querySelectorAll(
        ".header-component-container .ant-v5-select-selection-item, .header-component-container [title], .header-component-container"
      )
    );

    for (let index = 0; index < candidates.length; index += 1) {
      const text = String(candidates[index].textContent || candidates[index].getAttribute("title") || "")
        .replace(/\s+/g, " ")
        .trim();
      if (!isIgnoredUserText(text) && text.length <= 40) {
        return text;
      }
    }

    return "";
  }

  function delay(ms) {
    return new Promise(function (resolve) {
      window.setTimeout(resolve, ms);
    });
  }

  function getVisibleText(node) {
    return String(node?.textContent || "").replace(/\s+/g, " ").trim();
  }

  function dispatchMouseEvent(element, type) {
    if (!element) {
      return;
    }

    element.dispatchEvent(
      new MouseEvent(type, {
        bubbles: true,
        cancelable: true,
        view: window,
      })
    );
  }

  function findAvatarTrigger() {
    return (
      document.querySelector(
        ".ant-v5-dropdown-trigger[class*='NavAvatar-module__userInfoWrapper'], .ant-v5-dropdown-trigger.avatar, [class*='NavAvatar-module__userInfoWrapper'], .header-component-container .ant-v5-avatar"
      ) || null
    );
  }

  function readVisibleAvatarDropdownUserText() {
    const menuItems = Array.from(
      document.querySelectorAll(
        ".ant-v5-dropdown:not(.ant-v5-dropdown-hidden) .ant-v5-dropdown-menu-item, .ant-v5-dropdown-menu:not(.ant-v5-dropdown-menu-hidden) .ant-v5-dropdown-menu-item"
      )
    );

    const userItem =
      menuItems.find(function (item) {
        return String(item.className || "").indexOf("NavAvatar-module__userAvatar") >= 0;
      }) || menuItems[0] || null;
    const candidates = userItem
      ? Array.from(
          userItem.querySelectorAll(
            ".ant-v5-dropdown-menu-title-content, [class*='title-content'], span, div"
          )
        )
      : [];
    if (userItem) {
      candidates.unshift(userItem);
    }

    for (let index = 0; index < candidates.length; index += 1) {
      const text = getVisibleText(candidates[index]);
      if (!isIgnoredUserText(text) && text.length <= 50) {
        return text;
      }
    }

    return "";
  }

  async function resolveCurrentUserText() {
    const avatar = findAvatarTrigger();
    if (avatar) {
      dispatchMouseEvent(avatar, "mouseenter");
      dispatchMouseEvent(avatar, "mouseover");
      dispatchMouseEvent(avatar, "mousemove");
      await delay(180);
      const dropdownText = readVisibleAvatarDropdownUserText();
      dispatchMouseEvent(avatar, "mouseleave");
      if (dropdownText) {
        return dropdownText;
      }
    }

    return getCurrentUserText();
  }

  function inferRole(subtaskData, overrideRole) {
    if (overrideRole === "audit" || overrideRole === "label") {
      return overrideRole;
    }

    const currentKind = getHomeTaskKind();
    if (currentKind?.role) {
      return currentKind.role;
    }

    const missionType = String(getUrlParams().missionType || "").toLowerCase();
    if (missionType === "check" || missionType === "audit" || missionType === "review") {
      return "audit";
    }

    const type = String(subtaskData?.type || "").toUpperCase();
    const sourceType = String(subtaskData?.sourceType || "").toUpperCase();
    if (
      type.indexOf("CHECK") >= 0 ||
      type.indexOf("REVIEW") >= 0 ||
      type.indexOf("AUDIT") >= 0 ||
      sourceType.indexOf("CHECK") >= 0
    ) {
      return "audit";
    }

    return "label";
  }

  function getCompletionText(subtaskData) {
    if (subtaskData?.gmtCommit) {
      return "已完成";
    }

    const status = Number(subtaskData?.status);
    return Number.isFinite(status) && status > 0 ? "已完成" : "未完成";
  }

  function buildCsvBasePatch(subtaskData, durationSeconds) {
    return {
      任务名称: String(subtaskData?.taskName || ""),
      任务ID: String(subtaskData?.taskId || ""),
      分包ID: String(subtaskData?.batchId || ""),
      题数: String(subtaskData?.size || ""),
      "有效时长(秒)": formatDurationForCsv(durationSeconds),
    };
  }

  function getUserNameFromRecord(record) {
    return String(
      record?.userName ||
        record?.operatorName ||
        record?.operator ||
        record?.nickName ||
        record?.displayName ||
        ""
    ).trim();
  }

  function buildPayload(subtaskData, durationSeconds, reason, context) {
    const payloadContext = context && typeof context === "object" ? context : {};
    const urlParams = getUrlParams();
    const dataList = Array.isArray(subtaskData?.dataList) ? subtaskData.dataList : [];
    const firstItem = dataList[0] || {};
    const normalizedDurationSeconds = roundDurationSeconds(durationSeconds);
    const role = inferRole(subtaskData, payloadContext.role);
    const batchId = String(subtaskData?.batchId || "");
    const subTaskId = String(subtaskData?.id || urlParams.subTaskId || "");
    const userName =
      payloadContext.userName ||
      getUserNameFromRecord(subtaskData) ||
      getUserNameFromRecord(firstItem) ||
      "";
    const completed = getCompletionText(subtaskData);
    const now = new Date().toISOString();

    return {
      schemaVersion: 1,
      source: "chromium-extension",
      project: "alibaba-labelx/asr-judgement",
      reason: reason || "manual",
      uploadedAt: now,
      mergeKey: {
        batchId: batchId,
      },
      url: {
        projectId: urlParams.projectId,
        subTaskId: urlParams.subTaskId,
        missionType: urlParams.missionType,
      },
      csvColumns: CSV_COLUMNS.slice(),
      csvPatch: buildCsvBasePatch(subtaskData, normalizedDurationSeconds),
      roleRecord: {
        role: role,
        subTaskId: subTaskId,
        taskId: String(subtaskData?.taskId || ""),
        batchId: batchId,
        userId: String(firstItem?.userId || ""),
        userName: userName,
        receiveTime: String(subtaskData?.gmtCreate || ""),
        submitTime: String(subtaskData?.gmtCommit || ""),
        completed: completed,
      },
      metrics: {
        itemCount: Number(subtaskData?.size) || dataList.length,
        fetchedItemCount: dataList.length,
        durationSeconds: normalizedDurationSeconds,
        durationText: formatDurationForCsv(normalizedDurationSeconds),
        answeredCount: dataList.filter(function (item) {
          return Array.isArray(item?.result?.markResult) && item.result.markResult.some(Boolean);
        }).length,
      },
      rawKeys: {
        subTaskType: String(subtaskData?.type || ""),
        sourceType: String(subtaskData?.sourceType || ""),
        status: subtaskData?.status ?? null,
        labelModel: String(subtaskData?.labelModel || ""),
      },
      dedupeKey: [
        batchId,
        subTaskId,
        reason || "manual",
        new Date().toISOString().slice(0, 10),
      ].join("|"),
    };
  }

  function isHomePage() {
    return (
      location.hostname === "labelx.alibaba-inc.com" &&
      Boolean(getHomeTaskKind())
    );
  }

  function isStatsPage() {
    return (
      isHomePage() ||
      (location.hostname === "labelx.alibaba-inc.com" &&
        String(location.pathname || "").toLowerCase().indexOf("/corpora/labeling/sdk") >= 0)
    );
  }

  function getProjectIdFromUrl() {
    const params = new URLSearchParams(location.search || "");
    return normalizeUrlParam(params.get("projectId") || params.get("appId") || "");
  }

  function enrichSubtaskData(detailData, summary, taskMap, kind) {
    const taskId = String(detailData?.taskId || summary?.taskId || "");
    const task = taskMap[taskId] || {};
    return Object.assign({}, detailData || {}, {
      id: detailData?.id || summary?.id,
      type: detailData?.type || summary?.type,
      taskId: taskId,
      batchId: detailData?.batchId || summary?.batchId,
      status: detailData?.status ?? summary?.status,
      gmtCreate: detailData?.gmtCreate || summary?.gmtCreate,
      gmtCommit: detailData?.gmtCommit || summary?.gmtCommit,
      taskName: detailData?.taskName || summary?.taskName || task.name,
      size: detailData?.size || summary?.size,
      labelModel: detailData?.labelModel || summary?.labelModel || task.labelModel,
      sourceType: kind?.key || summary?.sourceType || "",
    });
  }

  async function mapLimit(items, limit, handler) {
    const result = [];
    let cursor = 0;
    const workers = new Array(Math.max(1, Math.min(limit, items.length || 1)))
      .fill(null)
      .map(async function () {
        while (cursor < items.length) {
          const index = cursor;
          cursor += 1;
          result[index] = await handler(items[index], index);
        }
      });
    await Promise.all(workers);
    return result;
  }

  function createState() {
    return {
      started: false,
      uploading: false,
      lastUploadAt: null,
      lastUploadReason: "",
      lastUploadOk: null,
      lastMessage: "",
      nextScheduleAt: null,
      schedule: {
        enabled: true,
        times: DEFAULT_UPLOAD_TIMES.slice(),
        jitterMinutes: DEFAULT_UPLOAD_JITTER_MINUTES,
        source: "local",
      },
    };
  }

  function createRuntime(deps) {
    const options = deps && typeof deps === "object" ? deps : {};
    let state = createState();
    let scheduleTimer = null;
    let uploadButtonTimer = null;
    let uploadButtonRoot = null;

    function getConfig() {
      return typeof options.getConfig === "function" ? options.getConfig() || {} : {};
    }

    function shouldApply() {
      return typeof options.shouldApply === "function" ? options.shouldApply() === true : false;
    }

    function notify() {
      if (typeof options.onStateChange === "function") {
        options.onStateChange(clone(state));
      }
    }

    function setMessage(ok, reason, message) {
      state.lastUploadOk = ok;
      state.lastUploadReason = reason || "";
      state.lastMessage = message || "";
      state.lastUploadAt = new Date().toISOString();
      notify();
    }

    function showToast(message, tone) {
      if (typeof options.showToast === "function") {
        options.showToast(message, tone || "info");
      }
    }

    function clearScheduleTimer() {
      if (scheduleTimer) {
        window.clearTimeout(scheduleTimer);
        scheduleTimer = null;
      }
    }

    function clearUploadButtonTimer() {
      if (uploadButtonTimer) {
        window.clearInterval(uploadButtonTimer);
        uploadButtonTimer = null;
      }
    }

    function removeUploadButton() {
      if (uploadButtonRoot && uploadButtonRoot.parentNode) {
        uploadButtonRoot.parentNode.removeChild(uploadButtonRoot);
      }
      uploadButtonRoot = null;
    }

    function setUploadButtonStatus(message, tone) {
      const button = uploadButtonRoot?.querySelector("button");
      if (!button) {
        return;
      }
      button.title = message || "上传统计";
      button.style.borderColor =
        tone === "error" ? "#fecaca" : tone === "success" ? "#bbf7d0" : "#bfdbfe";
      button.style.background =
        tone === "error" ? "#fef2f2" : tone === "success" ? "#f0fdf4" : "#eff6ff";
      button.style.color =
        tone === "error" ? "#b91c1c" : tone === "success" ? "#047857" : "#0958d9";
    }

    function resolveTopNavUploadMountPoint() {
      const avatar = findAvatarTrigger();
      if (avatar && avatar.parentNode) {
        return {
          host: avatar.parentNode,
          before: avatar,
        };
      }

      const header = document.querySelector(".header-component-container");
      return header ? { host: header, before: null } : null;
    }

    function ensureUploadButton() {
      if (!state.started || !isStatsPage() || getConfig().statsUploadEnabled === false) {
        removeUploadButton();
        return;
      }

      const mountPoint = resolveTopNavUploadMountPoint();
      if (!mountPoint || !mountPoint.host) {
        return;
      }

      if (
        uploadButtonRoot &&
        uploadButtonRoot.isConnected &&
        uploadButtonRoot.parentNode === mountPoint.host
      ) {
        return;
      }

      removeUploadButton();
      uploadButtonRoot = document.createElement("span");
      uploadButtonRoot.id = "asr-edge-judgement-stats-upload-entry";
      Object.assign(uploadButtonRoot.style, {
        display: "flex",
        alignItems: "center",
        flex: "0 0 auto",
        marginLeft: "8px",
        marginRight: "8px",
      });

      const button = document.createElement("button");
      button.type = "button";
      button.textContent = "上传统计";
      Object.assign(button.style, {
        border: "1px solid rgba(22, 119, 255, 0.42)",
        borderRadius: "6px",
        minHeight: "28px",
        padding: "0 12px",
        background: "#eff6ff",
        color: "#0958d9",
        fontSize: "12px",
        fontWeight: "700",
        lineHeight: "26px",
        cursor: "pointer",
        whiteSpace: "nowrap",
      });
      button.addEventListener("click", function () {
        button.disabled = true;
        button.style.opacity = "0.72";
        button.textContent = "上传中";
        setUploadButtonStatus("正在上传统计数据...", "info");
        void uploadNow(isHomePage() ? "home-manual" : "detail-manual")
          .then(function (result) {
            if (result?.ok === true) {
              setUploadButtonStatus(
                "已上传 " + String(result.payload?.payloadCount || 0) + " 个子任务",
                "success"
              );
              return;
            }
            setUploadButtonStatus(result?.message || "上传失败。", "error");
          })
          .catch(function (error) {
            setUploadButtonStatus(error && error.message ? error.message : String(error), "error");
          })
          .finally(function () {
            button.disabled = false;
            button.style.opacity = "1";
            button.textContent = "上传统计";
          });
      });

      uploadButtonRoot.appendChild(button);
      if (mountPoint.before && mountPoint.before.parentNode === mountPoint.host) {
        mountPoint.host.insertBefore(uploadButtonRoot, mountPoint.before);
      } else {
        mountPoint.host.appendChild(uploadButtonRoot);
      }
    }

    function startUploadButton() {
      clearUploadButtonTimer();
      ensureUploadButton();
      uploadButtonTimer = window.setInterval(ensureUploadButton, 1500);
    }

    async function refreshSchedule() {
      const config = getConfig();
      const fallback = {
        times: normalizeTimeList(config.statsUploadTimes),
        jitterMinutes: Math.max(
          0,
          Math.min(120, Number(config.statsUploadJitterMinutes) || DEFAULT_UPLOAD_JITTER_MINUTES)
        ),
      };
      const scheduleUrl = normalizeEndpoint(resolveScheduleEndpoint(config));
      if (!scheduleUrl) {
        state.schedule = Object.assign({ enabled: true, source: "local" }, fallback);
        notify();
        return state.schedule;
      }

      const url = new URL(scheduleUrl);
      const params = getUrlParams();
      if (params.projectId) {
        url.searchParams.set("projectId", params.projectId);
      }
      if (params.subTaskId) {
        url.searchParams.set("subTaskId", params.subTaskId);
      }

      try {
        const body = await fetchJson(url, {
          cache: "no-store",
          credentials: "omit",
          headers: {
            Accept: "application/json",
          },
        });
        state.schedule = parseScheduleResponse(body, config);
      } catch (error) {
        state.schedule = Object.assign({ enabled: true, source: "local-fallback" }, fallback);
        console.warn(LOG_PREFIX, "Failed to fetch schedule config:", error);
      }

      notify();
      return state.schedule;
    }

    function getNextScheduleDelay(schedule) {
      const times = normalizeTimeList(schedule?.times || DEFAULT_UPLOAD_TIMES);
      const now = new Date();
      let bestTime = null;

      times.forEach(function (timeText) {
        const parts = timeText.split(":");
        const target = new Date(now.getTime());
        target.setHours(Number(parts[0]), Number(parts[1]), 0, 0);
        if (target.getTime() <= now.getTime()) {
          target.setDate(target.getDate() + 1);
        }

        if (!bestTime || target.getTime() < bestTime.getTime()) {
          bestTime = target;
        }
      });

      const jitterMs = Math.floor(Math.random() * ((Number(schedule?.jitterMinutes) || 0) * 60000 + 1));
      return {
        targetTime: bestTime,
        delayMs: Math.max(1000, bestTime.getTime() - now.getTime() + jitterMs),
      };
    }

    function scheduleNextUpload() {
      clearScheduleTimer();
      const config = getConfig();
      if (
        !state.started ||
        !shouldApply() ||
        config.statsUploadEnabled === false ||
        config.statsAutoUploadOnSchedule === false ||
        state.schedule.enabled === false
      ) {
        state.nextScheduleAt = null;
        notify();
        return;
      }

      const next = getNextScheduleDelay(state.schedule);
      state.nextScheduleAt = next.targetTime.toISOString();
      notify();
      scheduleTimer = window.setTimeout(function () {
        scheduleTimer = null;
        void uploadNow("schedule").finally(function () {
          void refreshSchedule().finally(scheduleNextUpload);
        });
      }, next.delayMs);
    }

    async function collectPayload(reason) {
      return collectHomePayloads(reason);
    }

    async function collectHomePayloads(reason) {
      const projectId = getProjectIdFromUrl();
      if (!projectId) {
        throw new Error("当前页面 URL 中没有 projectId，无法上传全量统计。");
      }

      const userName = await resolveCurrentUserText();
      const kinds = getHomeTaskKindsToFetch();
      const kindPages = [];
      const errors = [];
      let skippedSubTaskCount = 0;
      let skippedDetailCount = 0;

      for (let index = 0; index < kinds.length; index += 1) {
        const kind = kinds[index];
        try {
          const tasksPage = await fetchHomeTasks(projectId, kind);
          const taskMap = {};
          tasksPage.list.forEach(function (task) {
            const taskId = String(task?.taskId || "");
            if (taskId) {
              taskMap[taskId] = task;
            }
          });

          const unfinishedPage = await fetchHomeSubTasks(projectId, false, kind);
          const finishedPage = await fetchHomeSubTasks(projectId, true, kind);
          kindPages.push({
            kind: kind,
            tasksPage: tasksPage,
            taskMap: taskMap,
            unfinishedPage: unfinishedPage,
            finishedPage: finishedPage,
          });
        } catch (error) {
          errors.push({
            kind: kind.key,
            message: error && error.message ? error.message : String(error),
          });
        }
      }

      const subtasks = [];
      kindPages.forEach(function (pageGroup) {
        const subtaskMap = {};
        pageGroup.unfinishedPage.list.concat(pageGroup.finishedPage.list).forEach(function (subtask) {
          const id = String(subtask?.id || "").trim();
          if (!id) {
            return;
          }

          const linkedTask = pageGroup.taskMap[String(subtask?.taskId || "")] || {};
          if (!isAsrJudgementTaskRecord(subtask, linkedTask)) {
            skippedSubTaskCount += 1;
            return;
          }

          subtaskMap[pageGroup.kind.key + ":" + id] = subtask;
        });
        Object.keys(subtaskMap).forEach(function (id) {
          subtasks.push({
            summary: subtaskMap[id],
            pageGroup: pageGroup,
          });
        });
      });

      if (subtasks.length === 0) {
        throw new Error(
          "首页未读取到 ASR 更优判断子任务，已跳过转写或其他项目数据。" +
            (errors.length ? " 失败：" + errors.map(function (item) {
              return item.kind + "=" + item.message;
            }).join("；") : "")
        );
      }

      const payloads = (await mapLimit(subtasks, 3, async function (entry) {
        const summary = entry.summary;
        const pageGroup = entry.pageGroup;
        const kind = pageGroup.kind;
        const linkedTask = pageGroup.taskMap[String(summary?.taskId || "")] || {};
        const detailData = await fetchSubtaskData(String(summary.id || "").trim());
        const enrichedData = enrichSubtaskData(detailData, summary, pageGroup.taskMap, kind);
        if (!isAsrJudgementTaskRecord(enrichedData, linkedTask)) {
          skippedDetailCount += 1;
          return null;
        }
        const durationSeconds = sumDurationSeconds(enrichedData.dataList);
        const payload = buildPayload(enrichedData, durationSeconds, reason || "home-manual", {
          role: kind.role,
          userName: userName || getUserNameFromRecord(summary),
        });
        payload.homeContext = {
          projectId: projectId,
          kind: kind.key,
          role: kind.role,
          kindLabel: kind.label,
          taskCount: pageGroup.tasksPage.recordCount,
          subTaskCount: subtasks.length,
          unfinishedCount: pageGroup.unfinishedPage.recordCount,
          finishedCount: pageGroup.finishedPage.recordCount,
          source: kind.route + " tasks/subTasks + subTask data",
        };
        return payload;
      })).filter(Boolean);

      if (payloads.length === 0) {
        throw new Error("首页列表中没有可上传的 ASR 更优判断统计数据。");
      }

      return {
        schemaVersion: 1,
        source: "chromium-extension",
        project: "alibaba-labelx/asr-judgement",
        reason: reason || "home-manual",
        uploadedAt: new Date().toISOString(),
        mode: "project-batch",
        mergeKey: {
          projectId: projectId,
        },
        payloads: payloads,
        summary: {
          projectId: projectId,
          taskCount: kindPages.reduce(function (total, item) {
            return total + (Number(item.tasksPage.recordCount) || 0);
          }, 0),
          subTaskCount: subtasks.length,
          payloadCount: payloads.length,
          skippedSubTaskCount: skippedSubTaskCount,
          skippedDetailCount: skippedDetailCount,
          kinds: kindPages.map(function (item) {
            return {
              kind: item.kind.key,
              role: item.kind.role,
              taskCount: item.tasksPage.recordCount,
              unfinishedCount: item.unfinishedPage.recordCount,
              finishedCount: item.finishedPage.recordCount,
            };
          }),
          errors: errors,
        },
      };
    }

    async function postPayload(payload) {
      const config = getConfig();
      const endpoint = resolveUploadEndpoint(config);
      if (!endpoint) {
        throw new Error("统计上传地址未配置。");
      }

      const controller = typeof AbortController === "function" ? new AbortController() : null;
      const timeoutMs = Math.max(1000, Number(config.statsUploadRequestTimeoutMs) || 20000);
      const timeoutId = controller
        ? window.setTimeout(function () {
            controller.abort();
          }, timeoutMs)
        : null;

      try {
        const response = await fetch(endpoint, {
          method: "POST",
          cache: "no-store",
          credentials: "omit",
          signal: controller ? controller.signal : undefined,
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json, text/plain, */*",
          },
          body: JSON.stringify(payload),
        });
        const contentType = response.headers.get("content-type") || "";
        const body = contentType.indexOf("application/json") >= 0 ? await response.json() : await response.text();
        if (!response.ok) {
          const responseSummary = summarizeUploadResponseBody(body);
          throw new Error(
            "上传失败：" +
              String(response.status) +
              (response.statusText ? " " + response.statusText : "") +
              "；地址：" +
              getEndpointLabel(endpoint) +
              (responseSummary ? "；响应：" + responseSummary : "")
          );
        }
        if (body && typeof body === "object" && body.success === false) {
          throw new Error(
            (body.message || "统计上传业务失败。") +
              "；地址：" +
              getEndpointLabel(endpoint)
          );
        }
        return body;
      } catch (error) {
        if (error && error.name === "AbortError") {
          throw new Error(
            "上传请求超时：" +
              String(timeoutMs) +
              "ms；地址：" +
              getEndpointLabel(endpoint)
          );
        }
        if (error instanceof TypeError) {
          throw new Error(
            "上传请求未发出或被浏览器/网络拦截：" +
              (error.message || String(error)) +
              "；地址：" +
              getEndpointLabel(endpoint)
          );
        }
        throw error;
      } finally {
        if (timeoutId) {
          window.clearTimeout(timeoutId);
        }
      }
    }

    async function uploadNow(reason) {
      const uploadReason = reason || "manual";
      const config = getConfig();
      if (!shouldApply()) {
        return {
          ok: false,
          reason: "runtime-disabled",
          message: "当前不是快判统计运行态，未上传统计。",
        };
      }
      if (config.statsUploadEnabled === false) {
        return {
          ok: false,
          reason: "stats-upload-disabled",
          message: "统计上传已关闭。",
        };
      }
      if (state.uploading) {
        return {
          ok: false,
          reason: "uploading",
          message: "统计上传正在进行中。",
        };
      }

      state.uploading = true;
      notify();
      try {
        const payload = await collectPayload(uploadReason);
        await postPayload(payload);
        setMessage(true, uploadReason, "统计数据已上传。");
        showToast("统计数据已上传。", "info");
        const uploadPayload = Array.isArray(payload.payloads) ? payload.payloads : [payload];
        return {
          ok: true,
          reason: uploadReason,
          message: "统计数据已上传。",
          payload: {
            batchId: uploadPayload[0]?.mergeKey?.batchId || "",
            subTaskId: uploadPayload[0]?.roleRecord?.subTaskId || "",
            itemCount: uploadPayload.reduce(function (total, item) {
              return total + (Number(item?.metrics?.itemCount) || 0);
            }, 0),
            payloadCount: uploadPayload.length,
          },
        };
      } catch (error) {
        const message = error && error.message ? error.message : String(error);
        setMessage(false, uploadReason, message);
        showToast("统计上传失败：" + message, "error");
        return {
          ok: false,
          reason: uploadReason,
          message: message,
        };
      } finally {
        state.uploading = false;
        notify();
      }
    }

    function start() {
      state.started = true;
      startUploadButton();
      void refreshSchedule().finally(scheduleNextUpload);
      notify();
    }

    function stop() {
      state.started = false;
      state.nextScheduleAt = null;
      clearScheduleTimer();
      clearUploadButtonTimer();
      removeUploadButton();
      notify();
    }

    function getState() {
      return clone(state);
    }

    return {
      start: start,
      stop: stop,
      uploadNow: uploadNow,
      getState: getState,
    };
  }

  globalThis.__ASREdgeAlibabaLabelxJudgementServer = {
    createRuntime: createRuntime,
    buildPayload: buildPayload,
    isAsrJudgementTaskRecord: isAsrJudgementTaskRecord,
    CSV_COLUMNS: CSV_COLUMNS.slice(),
  };
})();
