(function () {
  const constants = globalThis.ASREdgeConstants || {};
  const storage = globalThis.ASREdgeStorage || null;
  const platformLibrary = constants.PLATFORM_LIBRARY || {};
  const scriptLibrary = constants.SCRIPT_LIBRARY || {};
  const transcriptionProjectId = constants.TRANSCRIPTION_PROJECT_ID || "transcription";
  const judgementProjectId = constants.JUDGEMENT_PROJECT_ID || "judgement";
  const lightwheelScriptId = constants.LIGHTWHEEL_VIEW_PANEL_SCRIPT_ID || "lightwheelViewPanel";
  const dataBakerRoundOneQualityScriptId =
    constants.DATA_BAKER_ROUND_ONE_QUALITY_SCRIPT_ID || "dataBakerRoundOneQuality";
  const backendModeServer = constants.BACKEND_ENDPOINT_MODE_SERVER || "server";
  const backendModeLocal = constants.BACKEND_ENDPOINT_MODE_LOCAL || "local";
  const getBackendModeFromSettings =
    typeof constants.getBackendEndpointModeFromSettings === "function"
      ? constants.getBackendEndpointModeFromSettings
      : function (settings) {
          const mode = settings?.meta?.backendEndpointMode;
          return String(mode || "").trim().toLowerCase() === backendModeLocal
            ? backendModeLocal
            : backendModeServer;
        };
  const getBackendBaseUrlByMode =
    typeof constants.getBackendBaseUrlByMode === "function"
      ? constants.getBackendBaseUrlByMode
      : function (mode) {
          return String(mode || "").trim().toLowerCase() === backendModeLocal
            ? "http://127.0.0.1:3333"
            : "https://script.xiangtianzhen.store";
        };
  const buildBackendUrl =
    typeof constants.buildBackendUrl === "function"
      ? constants.buildBackendUrl
      : function (path, settingsOrMode) {
          const mode =
            typeof settingsOrMode === "string"
              ? settingsOrMode
              : getBackendModeFromSettings(settingsOrMode || {});
          const baseUrl = String(getBackendBaseUrlByMode(mode) || "").replace(/\/+$/, "");
          const normalizedPath = String(path || "").charAt(0) === "/" ? String(path || "") : "/" + String(path || "");
          return baseUrl + normalizedPath;
        };
  const dataBakerPageSizeOptions = (
    Array.isArray(constants.DATABAKER_PAGE_SIZE_OPTIONS)
      ? constants.DATABAKER_PAGE_SIZE_OPTIONS
      : ["5条/页", "10条/页", "20条/页", "50条/页", "100条/页"]
  ).map(function (item) {
    return String(item || "").replace(/\s+/g, "");
  });
  const dataBakerShortcutActions = constants.DATABAKER_ROUND_ONE_SHORTCUT_ACTIONS || [
    { key: "aiRecommendCurrentItem", label: "AI 推荐文本" },
    { key: "copyAiHeardText", label: "复制 AI 听音文本" },
    { key: "copyRecommendedText", label: "复制 AI 推荐文本" },
    { key: "fillRecommendedText", label: "填入推荐文本" },
    { key: "ignoreAiResult", label: "忽略 AI 推荐结果" },
    { key: "sentenceQualified", label: "句子判定：合格" },
    { key: "sentenceUnqualified", label: "句子判定：不合格" },
    { key: "taskPass", label: "任务判定：通过" },
    { key: "taskPartialReject", label: "任务判定：部分驳回" },
    { key: "taskFullReject", label: "任务判定：全部驳回" },
  ];
  const judgementAiSuggestionModels = Array.isArray(constants.JUDGEMENT_AI_AVAILABLE_MODELS)
    ? constants.JUDGEMENT_AI_AVAILABLE_MODELS
    : ["qwen3-omni-flash", "qwen3.5-omni-plus"];
  const judgementShortcutActions = constants.JUDGEMENT_SHORTCUT_ACTIONS || [
    { key: "choiceFirstBetter", label: "选择：第一个更好" },
    { key: "choiceSecondBetter", label: "选择：第二个更好" },
    { key: "choiceBothBad", label: "选择：都不好" },
    { key: "choiceUnsure", label: "选择：不确定或差不多" },
    { key: "choiceOtherDialect", label: "选择：其他方言或语种" },
    { key: "volumeUp", label: "增大音量" },
    { key: "volumeDown", label: "减小音量" },
    { key: "volumeReset", label: "重置音量" },
    { key: "rateUp", label: "提高倍速" },
    { key: "rateDown", label: "降低倍速" },
    { key: "rateReset", label: "重置倍速" },
    { key: "seekBackward", label: "后退当前音频" },
    { key: "seekForward", label: "前进当前音频" },
      { key: "playPause", label: "播放/暂停当前音频" },
  ];
  const transcriptionShortcutActions = [
    { key: "shortcutPlayPause", label: "播放 / 暂停" },
    { key: "shortcutValid", label: "当前题标有效" },
    { key: "shortcutInvalid", label: "当前题标无效" },
    { key: "shortcutFill", label: "当前题快速填入" },
    { key: "shortcutRemoveSpaces", label: "当前题去空格" },
    { key: "shortcutConvertNum", label: "当前题数字转换" },
    { key: "shortcutToggleFocus", label: "焦点切换" },
    { key: "shortcutBackward", label: "当前音频后退" },
    { key: "shortcutForward", label: "当前音频前进" },
    { key: "shortcutSpeedDown", label: "降低倍速" },
    { key: "shortcutSpeedUp", label: "提高倍速" },
    { key: "shortcutResetSpeed", label: "重置倍速" },
    { key: "shortcutVolDown", label: "降低音量" },
    { key: "shortcutVolUp", label: "提高音量" },
    { key: "shortcutResetVol", label: "重置音量" },
    { key: "shortcutCopyDuration", label: "复制当前音频时长" },
    { key: "shortcutUploadStats", label: "上传转写统计" },
  ];
  const judgementItemsPerPageOptions = [
    { value: "1 条/页", label: "1 条/页" },
    { value: "2 条/页", label: "2 条/页" },
    { value: "3 条/页", label: "3 条/页" },
    { value: "4 条/页", label: "4 条/页" },
    { value: "5 条/页", label: "5 条/页" },
    { value: "10 条/页", label: "10 条/页" },
    { value: "20 条/页", label: "20 条/页" },
    { value: "30 条/页", label: "30 条/页" },
    { value: "40 条/页", label: "40 条/页" },
    { value: "50 条/页", label: "50 条/页" },
    { value: "400 条/页", label: "400 条/页" },
  ];
  const mouseButtonLabels = {
    0: "MouseLeft",
    1: "MouseMiddle",
    2: "MouseRight",
    3: "MouseBack",
    4: "MouseForward",
  };
  let currentSettings = null;
  let transcriptionShortcutsDraft = {};
  let transcriptionRecordingKey = null;
  let stopTranscriptionRecordingListeners = null;
  let judgementShortcutsDraft = {};
  let judgementRecordingKey = null;
  let stopJudgementRecordingListeners = null;
  let dataBakerShortcutsDraft = {};
  let dataBakerRecordingKey = null;
  let stopDataBakerRecordingListeners = null;

  function getElement(id) {
    return document.getElementById(id);
  }

  function getSearchParams() {
    return new URLSearchParams(location.search || "");
  }

  function getCurrentDetailScriptId() {
    const scriptId = getSearchParams().get("script");
    return typeof scriptId === "string" && scriptLibrary[scriptId] ? scriptId : null;
  }

  function navigateToScript(scriptId) {
    const nextUrl = new URL(location.href);
    if (scriptId) {
      nextUrl.searchParams.set("script", scriptId);
    } else {
      nextUrl.searchParams.delete("script");
    }

    history.replaceState({}, "", nextUrl.toString());
    renderCurrentView();
  }

  function showError(message) {
    const node = getElement("options-error");
    node.textContent = String(message || "脚本中心加载失败。");
    node.classList.remove("hidden");
  }

  function hideError() {
    getElement("options-error").classList.add("hidden");
  }

  function clone(value) {
    return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
  }

  function escapeHtml(value) {
    return String(value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function clampNumber(value, fallback, min, max, precision) {
    const numericValue = Number(value);
    if (!Number.isFinite(numericValue)) {
      return fallback;
    }

    const clamped = Math.max(min, Math.min(max, numericValue));
    return typeof precision === "number" ? Number(clamped.toFixed(precision)) : clamped;
  }

  function normalizeJudgementItemsPerPage(value, fallback) {
    const text = typeof value === "string" ? value.trim() : "";
    if (
      text === "all" ||
      text === "全部" ||
      text === "全部/400条" ||
      text === "全部（400 条）" ||
      text === "全部（400条）" ||
      text === "400 条/页" ||
      text === "400条/页"
    ) {
      return "400 条/页";
    }

    if (
      text === "100 条/页" ||
      text === "100条/页" ||
      text === "150 条/页" ||
      text === "150条/页" ||
      text === "200 条/页" ||
      text === "200条/页"
    ) {
      return "50 条/页";
    }

    const validValues = judgementItemsPerPageOptions.map(function (option) {
      return option.value;
    });
    if (validValues.indexOf(text) >= 0) {
      return text;
    }

    return validValues.indexOf(fallback) >= 0 ? fallback : "50 条/页";
  }

  function normalizeHexColor(value, fallback) {
    const text = typeof value === "string" ? value.trim() : "";
    if (/^#[0-9a-fA-F]{6}$/.test(text)) {
      return text.toLowerCase();
    }

    return fallback;
  }

  function normalizeJudgementDiffColors(value, defaults) {
    const colorDefaults = defaults || {
      changeBackground: "#fef3c7",
      gapBackground: "#fee2e2",
      punctuationBackground: "#ede9fe",
    };
    const source = value && typeof value === "object" ? value : {};
    return {
      changeBackground: normalizeHexColor(
        source.changeBackground,
        colorDefaults.changeBackground || "#fef3c7"
      ),
      gapBackground: normalizeHexColor(
        source.gapBackground,
        colorDefaults.gapBackground || "#fee2e2"
      ),
      punctuationBackground: normalizeHexColor(
        source.punctuationBackground,
        colorDefaults.punctuationBackground || "#ede9fe"
      ),
    };
  }

  function normalizeTimeList(value, fallback) {
    const source = Array.isArray(value)
      ? value
      : typeof value === "string"
        ? value.split(/[,，\n]/)
        : Array.isArray(fallback)
          ? fallback
          : [];
    const result = [];

    source.forEach(function (item) {
      const text = String(item || "").trim();
      const match = text.match(/^([01]?\d|2[0-3]):([0-5]\d)$/);
      if (!match) {
        return;
      }

      const normalized = String(Number(match[1])).padStart(2, "0") + ":" + match[2];
      if (result.indexOf(normalized) < 0) {
        result.push(normalized);
      }
    });

    return result.length > 0 ? result : ["10:00", "16:00"];
  }

  function inferBackendModeFromEndpoint(endpointText, fallbackMode) {
    const text = String(endpointText || "").trim().toLowerCase();
    if (text.indexOf("127.0.0.1") >= 0 || text.indexOf("localhost") >= 0) {
      return backendModeLocal;
    }
    if (text.indexOf("http://") === 0 || text.indexOf("https://") === 0) {
      return backendModeServer;
    }
    return fallbackMode === backendModeLocal ? backendModeLocal : backendModeServer;
  }

  function normalizeJudgementAiAvailableModels(value, fallback) {
    const source = Array.isArray(value) ? value : Array.isArray(fallback) ? fallback : judgementAiSuggestionModels;
    const result = [];
    source.forEach(function (item) {
      const model = String(item || "").trim();
      if (
        !model ||
        judgementAiSuggestionModels.indexOf(model) < 0 ||
        result.indexOf(model) >= 0
      ) {
        return;
      }
      result.push(model);
    });
    return result.length > 0 ? result : judgementAiSuggestionModels.slice();
  }

  function normalizeJudgementAiModel(value, availableModels, fallback) {
    const model = String(value || "").trim();
    if (model && availableModels.indexOf(model) >= 0) {
      return model;
    }

    const fallbackModel = String(fallback || "").trim();
    if (fallbackModel && availableModels.indexOf(fallbackModel) >= 0) {
      return fallbackModel;
    }
    return availableModels[0] || "qwen3-omni-flash";
  }

  function formatJudgementAiModelLabel(model) {
    if (model === "qwen3-omni-flash") {
      return "qwen3-omni-flash（默认）";
    }
    if (model === "qwen3.5-omni-plus") {
      return "qwen3.5-omni-plus（预留）";
    }
    return model;
  }

  function renderJudgementAiModelOptions(models, selectedModel) {
    const select = getElement("judgement-ai-suggestion-model");
    if (!(select instanceof HTMLSelectElement)) {
      return;
    }

    select.innerHTML = models
      .map(function (model) {
        return (
          '<option value="' +
          escapeHtml(model) +
          '">' +
          escapeHtml(formatJudgementAiModelLabel(model)) +
          "</option>"
        );
      })
      .join("");
    select.value = normalizeJudgementAiModel(selectedModel, models, models[0]);
  }

  function normalizeJudgementRateStep(value, fallback) {
    const allowedValues = [0.1, 0.25, 0.5, 1];
    const numericValue = Number(value);
    if (allowedValues.indexOf(numericValue) >= 0) {
      return numericValue;
    }

    return allowedValues.indexOf(fallback) >= 0 ? fallback : 0.25;
  }

  function normalizeJudgementSeekStep(value, fallback) {
    const allowedValues = [0.1, 0.25, 0.5, 1];
    const numericValue = Number(value);
    if (allowedValues.indexOf(numericValue) >= 0) {
      return numericValue;
    }

    return allowedValues.indexOf(fallback) >= 0 ? fallback : 0.5;
  }

  function normalizeTranscriptionRateStep(value, fallback) {
    const allowedValues = [0.1, 0.25, 0.5, 1];
    const numericValue = Number(value);
    if (allowedValues.indexOf(numericValue) >= 0) {
      return numericValue;
    }
    return allowedValues.indexOf(fallback) >= 0 ? fallback : 0.1;
  }

  function normalizeTranscriptionSeekStep(value, fallback) {
    const allowedValues = [0.5, 1, 2, 3, 5];
    const numericValue = Number(value);
    if (allowedValues.indexOf(numericValue) >= 0) {
      return numericValue;
    }
    return allowedValues.indexOf(fallback) >= 0 ? fallback : 1;
  }

  function hasOwn(target, key) {
    return Boolean(target) && Object.prototype.hasOwnProperty.call(target, key);
  }

  function formatBackendModeLabel(settings) {
    return getBackendModeFromSettings(settings) === backendModeLocal
      ? "本机（127.0.0.1:3333）"
      : "服务器（script.xiangtianzhen.store）";
  }

  function isLabelxScript(scriptId) {
    return scriptId === transcriptionProjectId || scriptId === judgementProjectId;
  }

  function isDataBakerScript(scriptId) {
    return scriptId === dataBakerRoundOneQualityScriptId;
  }

  function normalizeDataBakerTimeoutMs(value) {
    const number = Number(value);
    if (!Number.isFinite(number)) {
      return 120000;
    }
    return Math.min(300000, Math.max(1000, Math.round(number)));
  }

  function dataBakerTimeoutMsToSeconds(value) {
    return Math.round(normalizeDataBakerTimeoutMs(value) / 1000);
  }

  function dataBakerTimeoutSecondsToMs(value) {
    const seconds = Number(value);
    if (!Number.isFinite(seconds)) {
      return 120000;
    }
    return Math.min(300, Math.max(1, Math.round(seconds))) * 1000;
  }

  function normalizeDataBakerPageSize(value, fallback) {
    const text = String(value || "").replace(/\s+/g, "");
    const fallbackText = String(fallback || "50条/页").replace(/\s+/g, "");

    if (dataBakerPageSizeOptions.indexOf(text) >= 0) {
      return text;
    }
    if (dataBakerPageSizeOptions.indexOf(fallbackText) >= 0) {
      return fallbackText;
    }
    return "50条/页";
  }

  function normalizeNullableShortcut(shortcut) {
    const normalized = normalizeShortcut(shortcut);
    return normalized && (normalized.key || typeof normalized.button === "number")
      ? normalized
      : null;
  }

  function normalizeDataBakerShortcuts(shortcuts) {
    const source = shortcuts && typeof shortcuts === "object" ? shortcuts : {};
    const result = {};
    dataBakerShortcutActions.forEach(function (action) {
      result[action.key] = hasOwn(source, action.key)
        ? normalizeNullableShortcut(source[action.key])
        : null;
    });
    return result;
  }

  function getLabelxActiveScriptId(settings) {
    return settings?.platforms?.alibabaLabelx?.scriptCenter?.activeProjectId || transcriptionProjectId;
  }

  function getDataBakerRoundOneConfig(settings) {
    const defaults =
      constants.DEFAULT_SETTINGS?.platforms?.dataBaker?.scripts?.roundOneQuality || {};
    const current =
      settings?.platforms?.dataBaker?.scripts?.roundOneQuality || {};

    const config = Object.assign(
      {
        id: dataBakerRoundOneQualityScriptId,
        enabled: true,
        aiRecommendEnabled: true,
        aiRecommendRequestTimeoutMs: 120000,
        autoPageSizeEnabled: true,
        defaultPageSize: "50条/页",
        shortcuts: {},
      },
      defaults,
      current
    );

    config.aiRecommendRequestTimeoutMs = normalizeDataBakerTimeoutMs(
      config.aiRecommendRequestTimeoutMs
    );
    config.autoPageSizeEnabled = config.autoPageSizeEnabled !== false;
    config.defaultPageSize = normalizeDataBakerPageSize(config.defaultPageSize, "50条/页");
    config.shortcuts = normalizeDataBakerShortcuts(config.shortcuts);
    return config;
  }

  function isScriptEnabled(settings, scriptId) {
    if (scriptId === lightwheelScriptId) {
      return Boolean(
        settings?.platforms?.lightwheel?.enabled &&
          settings?.platforms?.lightwheel?.scripts?.viewPanel?.enabled
      );
    }

    if (isDataBakerScript(scriptId)) {
      const config = getDataBakerRoundOneConfig(settings);
      return Boolean(settings?.platforms?.dataBaker?.enabled !== false && config.enabled !== false);
    }

    if (isLabelxScript(scriptId)) {
      return Boolean(
        settings?.platforms?.alibabaLabelx?.enabled &&
          getLabelxActiveScriptId(settings) === scriptId
      );
    }

    return false;
  }

  function getScriptStatus(settings, scriptId) {
    if (scriptId === lightwheelScriptId) {
      return isScriptEnabled(settings, scriptId)
        ? { text: "已启用", tone: "enabled" }
        : { text: "未启用", tone: "disabled" };
    }

    if (isDataBakerScript(scriptId)) {
      const config = getDataBakerRoundOneConfig(settings);
      if (!isScriptEnabled(settings, scriptId)) {
        return { text: "未启用", tone: "disabled" };
      }
      return config.aiRecommendEnabled === false
        ? { text: "脚本已启用，AI 推荐已关闭", tone: "pending" }
        : { text: "已启用", tone: "enabled" };
    }

    const labelxEnabled = Boolean(settings?.platforms?.alibabaLabelx?.enabled);
    const activeScriptId = getLabelxActiveScriptId(settings);

    if (!labelxEnabled) {
      return { text: "未启用", tone: "disabled" };
    }

    if (activeScriptId === scriptId) {
      return { text: "当前生效", tone: "enabled" };
    }

    const activeScript = scriptLibrary[activeScriptId] || {};
    return {
      text: "同平台当前为 " + String(activeScript.shortLabel || activeScript.label || activeScriptId),
      tone: "pending",
    };
  }

  function getScriptHostText(scriptId) {
    if (scriptId === lightwheelScriptId) {
      return "https://label-cloud.lightwheel.net/w/video3/index.html?access=1";
    }

    if (isDataBakerScript(scriptId)) {
      return "https://datafactory.data-baker.com/v2/#/quality/roundOneCollect?collectId=...&checkType=0";
    }

    return "https://labelx.alibaba-inc.com/corpora/labeling/*";
  }

  function setScriptStatusNode(node, status) {
    node.textContent = status.text;
    node.className = "script-pill " + status.tone;
  }

  function normalizeTranscriptionConfig(settings) {
    const projectState =
      settings?.platforms?.alibabaLabelx?.scriptCenter?.projects?.[transcriptionProjectId] || {};
    const asrConfig = projectState.asrConfig || {};
    const defaults = constants.DEFAULT_ASR_CONFIG || {
      autoPlay: false,
      defaultValid: false,
      fillOnValid: true,
      clearOnInvalid: true,
      playbackRateValue: 1,
      resetRateValue: 1,
      rateStepValue: 0.1,
      seekStepSeconds: 1,
      volumeValue: 100,
      shortcutPlayPause: null,
      shortcutValid: null,
      shortcutInvalid: null,
      shortcutFill: null,
      shortcutRemoveSpaces: null,
      shortcutConvertNum: null,
      shortcutToggleFocus: null,
      shortcutBackward: null,
      shortcutForward: null,
      shortcutSpeedDown: null,
      shortcutSpeedUp: null,
      shortcutResetSpeed: null,
      shortcutVolDown: null,
      shortcutVolUp: null,
      shortcutResetVol: null,
      shortcutCopyDuration: null,
      shortcutUploadStats: null,
      statsUploadEnabled: true,
      statsUploadTimes: ["10:00", "16:00"],
      statsUploadJitterMinutes: 10,
      statsAutoUploadOnSchedule: true,
      statsUploadRequestTimeoutMs: 20000,
    };

    const shortcuts = {};
    transcriptionShortcutActions.forEach(function (action) {
      const sourceShortcut = hasOwn(asrConfig, action.key)
        ? asrConfig[action.key]
        : hasOwn(defaults, action.key)
          ? defaults[action.key]
          : null;
      shortcuts[action.key] = normalizeShortcut(sourceShortcut);
    });

    const resetRateValue = clampNumber(
      hasOwn(asrConfig, "resetRateValue")
        ? asrConfig.resetRateValue
        : hasOwn(asrConfig, "playbackRateValue")
          ? asrConfig.playbackRateValue
          : defaults.resetRateValue || defaults.playbackRateValue || 1,
      defaults.resetRateValue || defaults.playbackRateValue || 1,
      0.25,
      5,
      2
    );

    return {
      autoPlay: asrConfig.autoPlay === true,
      defaultValid: asrConfig.defaultValid === true,
      fillOnValid: asrConfig.fillOnValid !== false,
      clearOnInvalid: asrConfig.clearOnInvalid !== false,
      playbackRateValue: clampNumber(
        hasOwn(asrConfig, "playbackRateValue") ? asrConfig.playbackRateValue : resetRateValue,
        resetRateValue,
        0.25,
        5,
        2
      ),
      resetRateValue: resetRateValue,
      rateStepValue: normalizeTranscriptionRateStep(
        asrConfig.rateStepValue,
        defaults.rateStepValue || 0.1
      ),
      seekStepSeconds: normalizeTranscriptionSeekStep(
        asrConfig.seekStepSeconds,
        defaults.seekStepSeconds || 1
      ),
      volumeValue: clampNumber(
        asrConfig.volumeValue,
        defaults.volumeValue || 100,
        0,
        1000,
        0
      ),
      shortcuts: shortcuts,
      statsUploadEnabled: true,
      statsUploadTimes: normalizeTimeList(asrConfig.statsUploadTimes, defaults.statsUploadTimes),
      statsUploadJitterMinutes: clampNumber(
        asrConfig.statsUploadJitterMinutes,
        defaults.statsUploadJitterMinutes || 10,
        0,
        120,
        0
      ),
      statsAutoUploadOnSchedule: true,
      statsUploadRequestTimeoutMs: clampNumber(
        asrConfig.statsUploadRequestTimeoutMs,
        defaults.statsUploadRequestTimeoutMs || 20000,
        1000,
        120000,
        0
      ),
    };
  }

  function normalizeJudgementConfig(settings) {
    const projectState =
      settings?.platforms?.alibabaLabelx?.scriptCenter?.projects?.[judgementProjectId] || {};
    const asrConfig = projectState.asrConfig || {};
    const defaults = constants.DEFAULT_JUDGEMENT_ASR_CONFIG || {
      autoPlay: true,
      autoResetRate: true,
      resetRateValue: 1.0,
      playbackRateValue: 1.0,
      rateStepValue: 0.25,
      seekStepSeconds: 0.5,
      volumeValue: 100,
      itemsPerPage: "50 条/页",
      virtualWindowEnabled: false,
      asrDiffViewEnabled: true,
      asrDiffColors: {
        changeBackground: "#fef3c7",
        gapBackground: "#fee2e2",
        punctuationBackground: "#ede9fe",
      },
      compactCardEnabled: true,
      thunderQuestionEnabled: true,
      autoAdvanceAfterChoice: false,
      statsUploadEnabled: true,
      statsScheduleUrl: "",
      statsUploadTimes: ["10:00", "16:00"],
      statsUploadJitterMinutes: 10,
      statsAutoUploadOnSubtaskOpen: false,
      statsAutoUploadOnSchedule: true,
      statsUploadRequestTimeoutMs: 20000,
      aiSuggestionEnabled: false,
      aiSuggestionRequestTimeoutMs: 120000,
      aiSuggestionModel: "qwen3-omni-flash",
      aiSuggestionAvailableModels: judgementAiSuggestionModels.slice(),
      shortcuts: {
        volumeUp: {
          ctrl: false,
          alt: false,
          shift: false,
          meta: false,
          key: "[",
          button: null,
        },
        volumeDown: {
          ctrl: false,
          alt: false,
          shift: false,
          meta: false,
          key: "]",
          button: null,
        },
        volumeReset: {
          ctrl: false,
          alt: false,
          shift: false,
          meta: false,
          key: "\\",
          button: null,
        },
        seekBackward: {
          ctrl: false,
          alt: false,
          shift: false,
          meta: false,
          key: "ArrowLeft",
          button: null,
        },
        seekForward: {
          ctrl: false,
          alt: false,
          shift: false,
          meta: false,
          key: "ArrowRight",
          button: null,
        },
      },
    };
    const shortcuts = {};
    const asrDiffColors = normalizeJudgementDiffColors(
      asrConfig.asrDiffColors,
      defaults.asrDiffColors
    );

    judgementShortcutActions.forEach(function (action) {
      const shortcut = hasOwn(asrConfig.shortcuts || {}, action.key)
        ? asrConfig.shortcuts[action.key]
        : hasOwn(defaults.shortcuts || {}, action.key)
        ? defaults.shortcuts[action.key]
        : null;
      shortcuts[action.key] = normalizeShortcut(shortcut);
    });

    const defaultPlaybackRate = clampNumber(
      hasOwn(asrConfig, "resetRateValue") ? asrConfig.resetRateValue : asrConfig.playbackRateValue,
      defaults.resetRateValue || defaults.playbackRateValue || 1,
      0.25,
      5,
      2
    );

    return {
      autoPlay: asrConfig.autoPlay !== false,
      autoResetRate: true,
      resetRateValue: defaultPlaybackRate,
      playbackRateValue: defaultPlaybackRate,
      rateStepValue: normalizeJudgementRateStep(
        asrConfig.rateStepValue,
        defaults.rateStepValue || 0.25
      ),
      seekStepSeconds: normalizeJudgementSeekStep(
        asrConfig.seekStepSeconds,
        defaults.seekStepSeconds || 0.5
      ),
      volumeValue:
        typeof asrConfig.volumeValue === "number" && asrConfig.volumeValue >= 0
          ? asrConfig.volumeValue
          : defaults.volumeValue,
      itemsPerPage: normalizeJudgementItemsPerPage(
        asrConfig.itemsPerPage,
        defaults.itemsPerPage || "50 条/页"
      ),
      virtualWindowEnabled: false,
      asrDiffViewEnabled: asrConfig.asrDiffViewEnabled !== false,
      asrDiffColors: asrDiffColors,
      compactCardEnabled: asrConfig.compactCardEnabled !== false,
      thunderQuestionEnabled: asrConfig.thunderQuestionEnabled !== false,
      autoAdvanceAfterChoice: asrConfig.autoAdvanceAfterChoice === true,
      statsUploadEnabled: true,
      statsScheduleUrl:
        typeof asrConfig.statsScheduleUrl === "string" ? asrConfig.statsScheduleUrl.trim() : "",
      statsUploadTimes: normalizeTimeList(
        asrConfig.statsUploadTimes,
        defaults.statsUploadTimes
      ),
      statsUploadJitterMinutes: clampNumber(
        asrConfig.statsUploadJitterMinutes,
        defaults.statsUploadJitterMinutes || 10,
        0,
        120,
        0
      ),
      statsAutoUploadOnSubtaskOpen: false,
      statsAutoUploadOnSchedule: true,
      statsUploadRequestTimeoutMs: clampNumber(
        asrConfig.statsUploadRequestTimeoutMs,
        defaults.statsUploadRequestTimeoutMs || 20000,
        1000,
        120000,
        0
      ),
      aiSuggestionEnabled: asrConfig.aiSuggestionEnabled === true,
      aiSuggestionRequestTimeoutMs: clampNumber(
        asrConfig.aiSuggestionRequestTimeoutMs,
        defaults.aiSuggestionRequestTimeoutMs || 120000,
        1000,
        180000,
        0
      ),
      aiSuggestionAvailableModels: normalizeJudgementAiAvailableModels(
        asrConfig.aiSuggestionAvailableModels,
        defaults.aiSuggestionAvailableModels
      ),
      aiSuggestionModel: normalizeJudgementAiModel(
        asrConfig.aiSuggestionModel,
        normalizeJudgementAiAvailableModels(
          asrConfig.aiSuggestionAvailableModels,
          defaults.aiSuggestionAvailableModels
        ),
        defaults.aiSuggestionModel || "qwen3-omni-flash"
      ),
      shortcuts: shortcuts,
    };
  }

  function normalizeShortcut(shortcut) {
    if (!shortcut || typeof shortcut !== "object") {
      return null;
    }

    const hasKey = typeof shortcut.key === "string" && shortcut.key.length > 0;
    const hasButton = typeof shortcut.button === "number";
    if (!hasKey && !hasButton) {
      return null;
    }

    return {
      ctrl: shortcut.ctrl === true,
      alt: shortcut.alt === true,
      shift: shortcut.shift === true,
      meta: shortcut.meta === true,
      key: hasKey ? shortcut.key : null,
      button: hasButton ? shortcut.button : null,
    };
  }

  function normalizeKeyName(key) {
    if (key === " ") {
      return "Space";
    }
    return String(key || "");
  }

  function formatShortcut(shortcut) {
    const normalized = normalizeShortcut(shortcut);
    if (!normalized) {
      return "未设置";
    }

    const parts = [];
    if (normalized.ctrl) {
      parts.push("Ctrl");
    }
    if (normalized.alt) {
      parts.push("Alt");
    }
    if (normalized.shift) {
      parts.push("Shift");
    }
    if (normalized.meta) {
      parts.push("Meta");
    }

    if (typeof normalized.button === "number") {
      parts.push(mouseButtonLabels[normalized.button] || "Mouse" + normalized.button);
    } else {
      parts.push(normalizeKeyName(normalized.key));
    }

    return parts.join(" + ");
  }

  function isModifierOnlyKey(key) {
    return ["Control", "Alt", "Shift", "Meta"].indexOf(key) >= 0;
  }

  function shortcutFromKeyboardEvent(event) {
    if (event.key === "Escape") {
      return null;
    }

    if (isModifierOnlyKey(event.key)) {
      return false;
    }

    return {
      ctrl: event.ctrlKey === true,
      alt: event.altKey === true,
      shift: event.shiftKey === true,
      meta: event.metaKey === true,
      key: event.key === " " ? "Space" : String(event.key),
      button: null,
    };
  }

  function shortcutFromMouseEvent(event) {
    return {
      ctrl: event.ctrlKey === true,
      alt: event.altKey === true,
      shift: event.shiftKey === true,
      meta: event.metaKey === true,
      key: null,
      button: event.button,
    };
  }

  function ensureShortcutDraft() {
    judgementShortcutActions.forEach(function (action) {
      if (!Object.prototype.hasOwnProperty.call(judgementShortcutsDraft, action.key)) {
        judgementShortcutsDraft[action.key] = null;
      }
    });
  }

  function renderJudgementShortcutGrid() {
    const grid = getElement("judgement-shortcut-grid");
    if (!grid) {
      return;
    }

    ensureShortcutDraft();
    grid.innerHTML = judgementShortcutActions
      .map(function (action) {
        const recording = judgementRecordingKey === action.key;
        return [
          '<div class="shortcut-row">',
          '<span class="shortcut-label">' + escapeHtml(action.label) + "</span>",
          '<span class="shortcut-value">' +
            escapeHtml(recording ? "录制中..." : formatShortcut(judgementShortcutsDraft[action.key])) +
            "</span>",
          '<button type="button" class="secondary-button" data-record-judgement-shortcut="' +
            escapeHtml(action.key) +
            '">' +
            (recording ? "录制中" : "录制") +
            "</button>",
          '<button type="button" class="ghost-button" data-clear-judgement-shortcut="' +
            escapeHtml(action.key) +
            '">删除</button>',
          "</div>",
        ].join("");
      })
      .join("");

    Array.from(grid.querySelectorAll("[data-record-judgement-shortcut]")).forEach(function (button) {
      button.addEventListener("click", function () {
        startJudgementShortcutRecording(button.getAttribute("data-record-judgement-shortcut"));
      });
    });

    Array.from(grid.querySelectorAll("[data-clear-judgement-shortcut]")).forEach(function (button) {
      button.addEventListener("click", function () {
        const key = button.getAttribute("data-clear-judgement-shortcut");
        judgementShortcutsDraft[key] = null;
        if (judgementRecordingKey === key) {
          stopJudgementShortcutRecording("快捷键录制已取消。");
          return;
        }
        setJudgementRecordingStatus("快捷键已删除，保存后生效。");
        renderJudgementShortcutGrid();
      });
    });
  }

  function setJudgementRecordingStatus(text) {
    const node = getElement("judgement-recording-status");
    if (!node) {
      return;
    }

    node.textContent = text || "";
    node.classList.toggle("hidden", !text);
  }

  function stopJudgementShortcutRecording(statusText) {
    if (typeof stopJudgementRecordingListeners === "function") {
      stopJudgementRecordingListeners();
      stopJudgementRecordingListeners = null;
    }

    judgementRecordingKey = null;
    setJudgementRecordingStatus(statusText || "");
    renderJudgementShortcutGrid();
  }

  function applyRecordedJudgementShortcut(shortcut) {
    if (!judgementRecordingKey || shortcut === false) {
      return;
    }

    if (!shortcut) {
      stopJudgementShortcutRecording("已取消快捷键录制。");
      return;
    }

    judgementShortcutsDraft[judgementRecordingKey] = normalizeShortcut(shortcut);
    stopJudgementShortcutRecording("快捷键已录制，保存后生效。");
  }

  function startJudgementShortcutRecording(actionKey) {
    if (!actionKey) {
      return;
    }

    if (typeof stopJudgementRecordingListeners === "function") {
      stopJudgementRecordingListeners();
    }

    judgementRecordingKey = actionKey;
    const action = judgementShortcutActions.find(function (item) {
      return item.key === actionKey;
    });

    setJudgementRecordingStatus(
      "正在录制「" + String(action?.label || actionKey) + "」：按键盘组合或鼠标按键，Esc 取消。"
    );

    function preventMouseDefaultOnce(event) {
      event.preventDefault();
      event.stopPropagation();
      if (typeof event.stopImmediatePropagation === "function") {
        event.stopImmediatePropagation();
      }
    }

    function suppressMouseFollowup() {
      ["mouseup", "auxclick", "contextmenu"].forEach(function (eventName) {
        window.addEventListener(eventName, preventMouseDefaultOnce, {
          capture: true,
          once: true,
        });
      });
      window.setTimeout(function () {
        ["mouseup", "auxclick", "contextmenu"].forEach(function (eventName) {
          window.removeEventListener(eventName, preventMouseDefaultOnce, true);
        });
      }, 800);
    }

    const keydownListener = function (event) {
      event.preventDefault();
      event.stopPropagation();
      if (typeof event.stopImmediatePropagation === "function") {
        event.stopImmediatePropagation();
      }
      applyRecordedJudgementShortcut(shortcutFromKeyboardEvent(event));
    };
    const mousedownListener = function (event) {
      event.preventDefault();
      event.stopPropagation();
      if (typeof event.stopImmediatePropagation === "function") {
        event.stopImmediatePropagation();
      }
      suppressMouseFollowup();
      applyRecordedJudgementShortcut(shortcutFromMouseEvent(event));
    };

    window.addEventListener("keydown", keydownListener, true);
    window.addEventListener("mousedown", mousedownListener, true);
    stopJudgementRecordingListeners = function () {
      window.removeEventListener("keydown", keydownListener, true);
      window.removeEventListener("mousedown", mousedownListener, true);
    };

    renderJudgementShortcutGrid();
  }

  function ensureDataBakerShortcutDraft() {
    dataBakerShortcutActions.forEach(function (action) {
      if (!hasOwn(dataBakerShortcutsDraft, action.key)) {
        dataBakerShortcutsDraft[action.key] = null;
      }
    });
  }

  function renderDataBakerShortcutGrid() {
    const grid = getElement("data-baker-shortcut-grid");
    if (!grid) {
      return;
    }

    ensureDataBakerShortcutDraft();
    grid.innerHTML = dataBakerShortcutActions
      .map(function (action) {
        const recording = dataBakerRecordingKey === action.key;
        return [
          '<div class="shortcut-row">',
          '<span class="shortcut-label">' + escapeHtml(action.label) + "</span>",
          '<span class="shortcut-value">' +
            escapeHtml(recording ? "录制中..." : formatShortcut(dataBakerShortcutsDraft[action.key])) +
            "</span>",
          '<button type="button" class="secondary-button" data-record-data-baker-shortcut="' +
            escapeHtml(action.key) +
            '">' +
            (recording ? "录制中" : "录制") +
            "</button>",
          '<button type="button" class="ghost-button" data-clear-data-baker-shortcut="' +
            escapeHtml(action.key) +
            '">删除</button>',
          "</div>",
        ].join("");
      })
      .join("");

    Array.from(grid.querySelectorAll("[data-record-data-baker-shortcut]")).forEach(function (button) {
      button.addEventListener("click", function () {
        startDataBakerShortcutRecording(button.getAttribute("data-record-data-baker-shortcut"));
      });
    });

    Array.from(grid.querySelectorAll("[data-clear-data-baker-shortcut]")).forEach(function (button) {
      button.addEventListener("click", function () {
        const key = button.getAttribute("data-clear-data-baker-shortcut");
        dataBakerShortcutsDraft[key] = null;
        if (dataBakerRecordingKey === key) {
          stopDataBakerShortcutRecording("快捷键录制已取消。");
          return;
        }
        setDataBakerRecordingStatus("快捷键已删除，保存后生效。");
        renderDataBakerShortcutGrid();
      });
    });
  }

  function setDataBakerRecordingStatus(text) {
    const node = getElement("data-baker-recording-status");
    if (!node) {
      return;
    }

    node.textContent = text || "";
    node.classList.toggle("hidden", !text);
  }

  function stopDataBakerShortcutRecording(statusText) {
    if (typeof stopDataBakerRecordingListeners === "function") {
      stopDataBakerRecordingListeners();
      stopDataBakerRecordingListeners = null;
    }

    dataBakerRecordingKey = null;
    setDataBakerRecordingStatus(statusText || "");
    renderDataBakerShortcutGrid();
  }

  function applyRecordedDataBakerShortcut(shortcut) {
    if (!dataBakerRecordingKey || shortcut === false) {
      return;
    }

    if (!shortcut) {
      stopDataBakerShortcutRecording("已取消快捷键录制。");
      return;
    }

    dataBakerShortcutsDraft[dataBakerRecordingKey] = normalizeNullableShortcut(shortcut);
    stopDataBakerShortcutRecording("快捷键已录制，保存后生效。");
  }

  function startDataBakerShortcutRecording(actionKey) {
    if (!actionKey) {
      return;
    }

    if (typeof stopDataBakerRecordingListeners === "function") {
      stopDataBakerRecordingListeners();
    }

    dataBakerRecordingKey = actionKey;
    const action = dataBakerShortcutActions.find(function (item) {
      return item.key === actionKey;
    });

    setDataBakerRecordingStatus(
      "正在录制「" + String(action?.label || actionKey) + "」：按键盘组合，Esc 取消。"
    );

    const keydownListener = function (event) {
      event.preventDefault();
      event.stopPropagation();
      if (typeof event.stopImmediatePropagation === "function") {
        event.stopImmediatePropagation();
      }
      applyRecordedDataBakerShortcut(shortcutFromKeyboardEvent(event));
    };

    window.addEventListener("keydown", keydownListener, true);
    stopDataBakerRecordingListeners = function () {
      window.removeEventListener("keydown", keydownListener, true);
    };

    renderDataBakerShortcutGrid();
  }

  function applyJudgementForm(settings) {
    const config = normalizeJudgementConfig(settings);
    judgementShortcutsDraft = clone(config.shortcuts) || {};
    getElement("judgement-volume").value = String(config.volumeValue);
    getElement("judgement-rate-step").value = String(config.rateStepValue);
    getElement("judgement-reset-rate").value = String(config.resetRateValue);
    getElement("judgement-seek-step").value = String(config.seekStepSeconds);
    getElement("judgement-items-per-page").value = config.itemsPerPage;
    getElement("judgement-auto-play").checked = config.autoPlay === true;
    getElement("judgement-asr-diff-view").checked = config.asrDiffViewEnabled !== false;
    getElement("judgement-diff-change-bg").value = config.asrDiffColors.changeBackground;
    getElement("judgement-diff-gap-bg").value = config.asrDiffColors.gapBackground;
    getElement("judgement-diff-punctuation-bg").value =
      config.asrDiffColors.punctuationBackground;
    getElement("judgement-compact-card").checked = config.compactCardEnabled !== false;
    getElement("judgement-thunder-question").checked = config.thunderQuestionEnabled !== false;
    getElement("judgement-auto-advance").checked = config.autoAdvanceAfterChoice === true;
    getElement("judgement-ai-suggestion-enabled").checked = config.aiSuggestionEnabled === true;
    getElement("judgement-ai-suggestion-timeout").value = String(config.aiSuggestionRequestTimeoutMs);
    renderJudgementAiModelOptions(config.aiSuggestionAvailableModels, config.aiSuggestionModel);
    stopJudgementShortcutRecording("");
    renderJudgementShortcutGrid();
    setStatus(
      "judgement-status",
      "当前后端地址由首页统一控制：" + formatBackendModeLabel(settings)
    );
  }

  function ensureTranscriptionShortcutDraft() {
    transcriptionShortcutActions.forEach(function (action) {
      if (!hasOwn(transcriptionShortcutsDraft, action.key)) {
        transcriptionShortcutsDraft[action.key] = null;
      }
    });
  }

  function renderTranscriptionShortcutGrid() {
    const grid = getElement("transcription-shortcut-grid");
    if (!grid) {
      return;
    }
    ensureTranscriptionShortcutDraft();
    grid.innerHTML = transcriptionShortcutActions
      .map(function (action) {
        const recording = transcriptionRecordingKey === action.key;
        return [
          '<div class="shortcut-row">',
          '<span class="shortcut-label">' + escapeHtml(action.label) + "</span>",
          '<span class="shortcut-value">' +
            escapeHtml(recording ? "录制中..." : formatShortcut(transcriptionShortcutsDraft[action.key])) +
            "</span>",
          '<button type="button" class="secondary-button" data-record-transcription-shortcut="' +
            escapeHtml(action.key) +
            '">' +
            (recording ? "录制中" : "录制") +
            "</button>",
          '<button type="button" class="ghost-button" data-clear-transcription-shortcut="' +
            escapeHtml(action.key) +
            '">删除</button>',
          "</div>",
        ].join("");
      })
      .join("");

    Array.from(grid.querySelectorAll("[data-record-transcription-shortcut]")).forEach(function (button) {
      button.addEventListener("click", function () {
        startTranscriptionShortcutRecording(button.getAttribute("data-record-transcription-shortcut"));
      });
    });

    Array.from(grid.querySelectorAll("[data-clear-transcription-shortcut]")).forEach(function (button) {
      button.addEventListener("click", function () {
        const key = button.getAttribute("data-clear-transcription-shortcut");
        transcriptionShortcutsDraft[key] = null;
        if (transcriptionRecordingKey === key) {
          stopTranscriptionShortcutRecording("快捷键录制已取消。");
          return;
        }
        setTranscriptionRecordingStatus("快捷键已删除，保存后生效。");
        renderTranscriptionShortcutGrid();
      });
    });
  }

  function setTranscriptionRecordingStatus(text) {
    const node = getElement("transcription-recording-status");
    if (!node) {
      return;
    }
    node.textContent = text || "";
    node.classList.toggle("hidden", !text);
  }

  function stopTranscriptionShortcutRecording(statusText) {
    if (typeof stopTranscriptionRecordingListeners === "function") {
      stopTranscriptionRecordingListeners();
      stopTranscriptionRecordingListeners = null;
    }
    transcriptionRecordingKey = null;
    setTranscriptionRecordingStatus(statusText || "");
    renderTranscriptionShortcutGrid();
  }

  function applyRecordedTranscriptionShortcut(shortcut) {
    if (!transcriptionRecordingKey || shortcut === false) {
      return;
    }
    if (!shortcut) {
      stopTranscriptionShortcutRecording("已取消快捷键录制。");
      return;
    }

    transcriptionShortcutsDraft[transcriptionRecordingKey] = normalizeShortcut(shortcut);
    stopTranscriptionShortcutRecording("快捷键已录制，保存后生效。");
  }

  function startTranscriptionShortcutRecording(actionKey) {
    if (!actionKey) {
      return;
    }
    if (typeof stopTranscriptionRecordingListeners === "function") {
      stopTranscriptionRecordingListeners();
    }

    transcriptionRecordingKey = actionKey;
    const action = transcriptionShortcutActions.find(function (item) {
      return item.key === actionKey;
    });
    setTranscriptionRecordingStatus(
      "正在录制「" + String(action?.label || actionKey) + "」：按键盘组合，Esc 取消。"
    );

    const keydownListener = function (event) {
      event.preventDefault();
      event.stopPropagation();
      if (typeof event.stopImmediatePropagation === "function") {
        event.stopImmediatePropagation();
      }
      applyRecordedTranscriptionShortcut(shortcutFromKeyboardEvent(event));
    };
    window.addEventListener("keydown", keydownListener, true);
    stopTranscriptionRecordingListeners = function () {
      window.removeEventListener("keydown", keydownListener, true);
    };

    renderTranscriptionShortcutGrid();
  }

  function applyTranscriptionForm(settings) {
    const config = normalizeTranscriptionConfig(settings);
    transcriptionShortcutsDraft = clone(config.shortcuts) || {};

    getElement("transcription-auto-play").checked = config.autoPlay === true;
    getElement("transcription-playback-rate").value = String(config.playbackRateValue);
    getElement("transcription-reset-rate").value = String(config.resetRateValue);
    getElement("transcription-rate-step").value = String(config.rateStepValue);
    getElement("transcription-seek-step").value = String(config.seekStepSeconds);
    getElement("transcription-volume").value = String(config.volumeValue);
    getElement("transcription-default-valid").checked = config.defaultValid === true;
    getElement("transcription-fill-on-valid").checked = config.fillOnValid !== false;
    getElement("transcription-clear-on-invalid").checked = config.clearOnInvalid !== false;

    stopTranscriptionShortcutRecording("");
    renderTranscriptionShortcutGrid();
    const backendLabel = formatBackendModeLabel(settings);
    setStatus(
      "transcription-status",
      "数据统计上传为脚本默认能力，已强制启用；定时上传按脚本能力强制启用。后端地址：全局 " +
        backendLabel
    );
  }

  async function saveTranscriptionSettings() {
    if (!storage || typeof storage.saveProjectSettings !== "function") {
      setStatus("transcription-status", "当前扩展版本不支持保存转写设置。");
      return false;
    }

    const current = normalizeTranscriptionConfig(currentSettings || {});
    const shortcuts = {};
    transcriptionShortcutActions.forEach(function (action) {
      shortcuts[action.key] = normalizeShortcut(transcriptionShortcutsDraft[action.key]);
    });

    setStatus("transcription-status", "正在保存转写设置...");
    try {
      currentSettings = await storage.saveProjectSettings(transcriptionProjectId, {
        autoPlay: getElement("transcription-auto-play").checked === true,
        playbackRateValue: clampNumber(
          getElement("transcription-playback-rate").value,
          current.playbackRateValue,
          0.25,
          5,
          2
        ),
        resetRateValue: clampNumber(
          getElement("transcription-reset-rate").value,
          current.resetRateValue,
          0.25,
          5,
          2
        ),
        rateStepValue: normalizeTranscriptionRateStep(
          getElement("transcription-rate-step").value,
          current.rateStepValue
        ),
        seekStepSeconds: normalizeTranscriptionSeekStep(
          getElement("transcription-seek-step").value,
          current.seekStepSeconds
        ),
        volumeValue: clampNumber(getElement("transcription-volume").value, current.volumeValue, 0, 1000, 0),
        defaultValid: getElement("transcription-default-valid").checked === true,
        fillOnValid: getElement("transcription-fill-on-valid").checked === true,
        clearOnInvalid: getElement("transcription-clear-on-invalid").checked === true,
        shortcutPlayPause: shortcuts.shortcutPlayPause,
        shortcutValid: shortcuts.shortcutValid,
        shortcutInvalid: shortcuts.shortcutInvalid,
        shortcutFill: shortcuts.shortcutFill,
        shortcutRemoveSpaces: shortcuts.shortcutRemoveSpaces,
        shortcutConvertNum: shortcuts.shortcutConvertNum,
        shortcutToggleFocus: shortcuts.shortcutToggleFocus,
        shortcutBackward: shortcuts.shortcutBackward,
        shortcutForward: shortcuts.shortcutForward,
        shortcutSpeedDown: shortcuts.shortcutSpeedDown,
        shortcutSpeedUp: shortcuts.shortcutSpeedUp,
        shortcutResetSpeed: shortcuts.shortcutResetSpeed,
        shortcutVolDown: shortcuts.shortcutVolDown,
        shortcutVolUp: shortcuts.shortcutVolUp,
        shortcutResetVol: shortcuts.shortcutResetVol,
        shortcutCopyDuration: shortcuts.shortcutCopyDuration,
        shortcutUploadStats: shortcuts.shortcutUploadStats,
      });
      applyTranscriptionForm(currentSettings);
      setStatus("transcription-status", "转写设置已保存；已打开详情页请刷新或等待自动同步。");
      return true;
    } catch (error) {
      setStatus(
        "transcription-status",
        "保存失败：" + (error && error.message ? error.message : String(error))
      );
      return false;
    }
  }

  function renderScriptCenter(settings) {
    renderHomeBackendEndpoint(settings);

    const center = getElement("script-center-view");
    const platformIds = Object.keys(platformLibrary);

    center.innerHTML = platformIds
      .map(function (platformId) {
        const platform = platformLibrary[platformId] || {};
        const scriptIds = Object.keys(scriptLibrary).filter(function (scriptId) {
          return scriptLibrary[scriptId]?.platformId === platformId;
        });

        const scriptMarkup = scriptIds
          .map(function (scriptId) {
            const script = scriptLibrary[scriptId] || {};
            const status = getScriptStatus(settings, scriptId);
            const active = status.tone === "enabled";

            return [
              '<article class="script-card' + (active ? " active" : "") + '">',
              '<div class="script-head">',
              '<div class="script-title">',
              "<h3>" + String(script.label || scriptId) + "</h3>",
              '<div class="meta-row">',
              '<span class="script-pill info">' + String(script.statusLabel || "脚本") + "</span>",
              '<span class="script-pill ' + status.tone + '">' + status.text + "</span>",
              "</div>",
              "</div>",
              "</div>",
              '<p class="script-copy">' + String(script.description || "") + "</p>",
              '<p class="script-copy">匹配 URL：' + getScriptHostText(scriptId) + "</p>",
              '<div class="script-actions">',
              '<button type="button" class="primary-button" data-open-script="' + scriptId + '">打开设置</button>',
              isScriptEnabled(settings, scriptId)
                ? '<button type="button" class="danger-button" data-disable-script="' + scriptId + '">关闭脚本</button>'
                : '<button type="button" class="secondary-button" data-enable-script="' + scriptId + '">启用脚本</button>',
              "</div>",
              "</article>",
            ].join("");
          })
          .join("");

        return [
          '<section class="platform-section">',
          '<div class="platform-head">',
          "<div>",
          "<h2>" + String(platform.label || platformId) + "</h2>",
          '<p class="platform-copy">' + String(platform.description || "") + "</p>",
          "</div>",
          '<div class="status-row">',
          '<span class="pill info">' + String(platform.host || "") + "</span>",
          "</div>",
          "</div>",
          '<div class="script-grid">' + scriptMarkup + "</div>",
          "</section>",
        ].join("");
      })
      .join("");

    Array.from(center.querySelectorAll("[data-open-script]")).forEach(function (button) {
      button.addEventListener("click", function () {
        navigateToScript(button.getAttribute("data-open-script"));
      });
    });

    Array.from(center.querySelectorAll("[data-enable-script]")).forEach(function (button) {
      button.addEventListener("click", function () {
        void toggleScript(button.getAttribute("data-enable-script"), true);
      });
    });

    Array.from(center.querySelectorAll("[data-disable-script]")).forEach(function (button) {
      button.addEventListener("click", function () {
        void toggleScript(button.getAttribute("data-disable-script"), false);
      });
    });
  }

  function renderHomeBackendEndpoint(settings) {
    const serverButton = getElement("home-endpoint-server");
    const localButton = getElement("home-endpoint-local");
    if (!(serverButton instanceof HTMLButtonElement) || !(localButton instanceof HTMLButtonElement)) {
      return;
    }

    const mode = getBackendModeFromSettings(settings);
    const statusNode = getElement("home-endpoint-status");
    const isLocal = mode === backendModeLocal;

    serverButton.classList.toggle("active", !isLocal);
    localButton.classList.toggle("active", isLocal);
    serverButton.setAttribute("aria-pressed", String(!isLocal));
    localButton.setAttribute("aria-pressed", String(isLocal));

    if (statusNode) {
      statusNode.textContent = [
        "当前已选择：" + (isLocal ? "本机（127.0.0.1:3333）" : "服务器（script.xiangtianzhen.store）"),
        "该设置统一控制 ASR 转写统计、ASR 快判统计、ASR 快判 AI 建议、标贝易采 AI 推荐。",
      ].join(" ");
    }
  }

  async function setHomeBackendEndpoint(mode) {
    if (!storage || typeof storage.patchSettings !== "function") {
      const statusNode = getElement("home-endpoint-status");
      if (statusNode) {
        statusNode.textContent = "当前扩展版本不支持保存后端接口地址。";
      }
      return;
    }

    const normalizedMode =
      String(mode || "").trim().toLowerCase() === backendModeLocal ? backendModeLocal : backendModeServer;
    const statusNode = getElement("home-endpoint-status");
    if (statusNode) {
      statusNode.textContent = "正在保存后端接口地址...";
    }

    try {
      currentSettings = await storage.patchSettings({
        meta: {
          backendEndpointMode: normalizedMode,
        },
      });
      renderHomeBackendEndpoint(currentSettings);
      if (statusNode) {
        statusNode.textContent =
          "后端接口地址已保存为" + (normalizedMode === backendModeLocal ? "本机" : "服务器") + "。";
      }
    } catch (error) {
      if (statusNode) {
        statusNode.textContent =
          "保存失败：" + (error && error.message ? error.message : String(error));
      }
    }
  }

  function renderDetailHeader(settings, scriptId) {
    const script = scriptLibrary[scriptId] || {};
    const platform = platformLibrary[script.platformId] || {};
    const status = getScriptStatus(settings, scriptId);

    getElement("detail-script-name").textContent = script.label || scriptId;
    getElement("detail-script-description").textContent = script.description || "";
    getElement("detail-script-note").textContent =
      script.note ||
      (isLabelxScript(scriptId)
        ? "同平台脚本互斥：启用这个脚本后，另一个 LabelX 脚本会自动切换为非生效状态。"
        : "当前脚本属于独立平台。");

    const statusNode = getElement("detail-script-status");
    statusNode.textContent = status.text;
    statusNode.className = "pill " + status.tone;

    const platformNode = getElement("detail-platform-pill");
    platformNode.textContent = String(platform.label || script.platformId || "未知平台");

    const enableButton = getElement("detail-enable-button");
    const disableButton = getElement("detail-disable-button");
    const enabled = isScriptEnabled(settings, scriptId);

    enableButton.disabled = enabled;
    disableButton.disabled = !enabled;
  }

  function showDetailPanel(scriptId) {
    getElement("detail-transcription-panel").classList.toggle("hidden", scriptId !== transcriptionProjectId);
    getElement("detail-judgement-panel").classList.toggle("hidden", scriptId !== judgementProjectId);
    getElement("detail-lightwheel-panel").classList.toggle("hidden", scriptId !== lightwheelScriptId);
    getElement("detail-data-baker-round-one-quality-panel").classList.toggle(
      "hidden",
      scriptId !== dataBakerRoundOneQualityScriptId
    );
  }

  function renderDetail(settings, scriptId) {
    renderDetailHeader(settings, scriptId);
    showDetailPanel(scriptId);
    setStatus("detail-status", "");

    if (scriptId === transcriptionProjectId) {
      applyTranscriptionForm(settings);
      setStatus(
        "detail-status",
        "ASR 转写当前为轻量工具栏模式（0.2.10）：可配置自动播放、倍速、步长、音量与快捷键；统计上传和定时上传已按脚本规则强制启用。"
      );
      return;
    }

    if (scriptId === judgementProjectId) {
      applyJudgementForm(settings);
      setStatus("judgement-status", "");
      return;
    }

    if (scriptId === lightwheelScriptId) {
      const enabled = isScriptEnabled(settings, scriptId);
      setStatus(
        "lightwheel-status",
        enabled
          ? "当前只启用了脚本中心状态位；Lightwheel 扩展运行时还没有迁入。"
          : "当前脚本未启用。启用后会先纳入 URL 检测和脚本中心管理。"
      );
    }

    if (scriptId === dataBakerRoundOneQualityScriptId) {
      applyDataBakerForm(settings);
      setStatus("data-baker-status", "");
    }
  }

  function applyDataBakerForm(settings) {
    const config = getDataBakerRoundOneConfig(settings);
    dataBakerShortcutsDraft = clone(config.shortcuts) || {};
    getElement("data-baker-ai-recommend-enabled").checked =
      config.aiRecommendEnabled !== false;
    getElement("data-baker-ai-recommend-timeout").value = String(
      dataBakerTimeoutMsToSeconds(config.aiRecommendRequestTimeoutMs)
    );
    getElement("data-baker-auto-page-size-enabled").checked =
      config.autoPageSizeEnabled !== false;
    getElement("data-baker-default-page-size").value = normalizeDataBakerPageSize(
      config.defaultPageSize,
      "50条/页"
    );
    stopDataBakerShortcutRecording("");
    renderDataBakerShortcutGrid();
  }

  async function saveDataBakerSettings() {
    if (!storage || typeof storage.patchSettings !== "function") {
      setStatus("data-baker-status", "当前扩展版本不支持保存标贝易采设置。");
      return false;
    }

    const timeoutInput = getElement("data-baker-ai-recommend-timeout").value;
    const aiRecommendEnabled = getElement("data-baker-ai-recommend-enabled").checked;
    const autoPageSizeEnabled = getElement("data-baker-auto-page-size-enabled").checked;
    const defaultPageSize = normalizeDataBakerPageSize(
      getElement("data-baker-default-page-size").value,
      "50条/页"
    );
    const timeoutMs = dataBakerTimeoutSecondsToMs(timeoutInput);
    const shortcuts = {};

    ensureDataBakerShortcutDraft();
    dataBakerShortcutActions.forEach(function (action) {
      shortcuts[action.key] = normalizeNullableShortcut(dataBakerShortcutsDraft[action.key]);
    });

    setStatus("data-baker-status", "正在保存标贝易采设置...");

    try {
      currentSettings = await storage.patchSettings({
        platforms: {
          dataBaker: {
            scripts: {
              roundOneQuality: {
                id: dataBakerRoundOneQualityScriptId,
                aiRecommendEnabled: aiRecommendEnabled,
                aiRecommendRequestTimeoutMs: timeoutMs,
                autoPageSizeEnabled: autoPageSizeEnabled,
                defaultPageSize: defaultPageSize,
                shortcuts: shortcuts,
              },
            },
          },
        },
      });
      renderCurrentView();
      setStatus(
        "data-baker-status",
        "标贝易采设置已保存；已打开的标贝易采页面未同步时请刷新页面。"
      );
      return true;
    } catch (error) {
      setStatus(
        "data-baker-status",
        "保存失败：" + (error && error.message ? error.message : String(error))
      );
      return false;
    }
  }

  function setStatus(targetId, text) {
    const node = getElement(targetId);
    if (node) {
      node.textContent = text || "";
    }
  }

  async function loadSettings() {
    if (!storage || typeof storage.getSettings !== "function") {
      throw new Error("扩展存储不可用。");
    }

    currentSettings = await storage.getSettings();
    return currentSettings;
  }

  async function toggleScript(scriptId, enabled) {
    if (!storage || typeof storage.setScriptEnabled !== "function") {
      setStatus("detail-status", "当前扩展版本不支持脚本启停。");
      return;
    }

    const script = scriptLibrary[scriptId] || {};
    const targetStatus = enabled ? "启用" : "关闭";
    setStatus("detail-status", "正在" + targetStatus + " " + String(script.label || scriptId) + "...");

    try {
      currentSettings = await storage.setScriptEnabled(scriptId, enabled);
      renderCurrentView();
      setStatus(
        "detail-status",
        String(script.label || scriptId) +
          (enabled
            ? " 已启用。如当前平台页面已打开，建议刷新一次。"
            : " 已关闭。")
      );
    } catch (error) {
      setStatus(
        "detail-status",
        targetStatus + "失败：" + (error && error.message ? error.message : String(error))
      );
    }
  }

  async function saveJudgementSettings() {
    if (!storage || typeof storage.saveProjectSettings !== "function") {
      setStatus("judgement-status", "当前扩展版本不支持保存语音判别设置。");
      return false;
    }

    const volumeValue = Number(getElement("judgement-volume").value);
    const rateStepValue = Number(getElement("judgement-rate-step").value);
    const resetRateValue = Number(getElement("judgement-reset-rate").value);
    const seekStepSeconds = Number(getElement("judgement-seek-step").value);
    const itemsPerPage = normalizeJudgementItemsPerPage(
      getElement("judgement-items-per-page").value,
      "50 条/页"
    );
    const autoPlay = Boolean(getElement("judgement-auto-play").checked);
    const asrDiffViewEnabled = Boolean(getElement("judgement-asr-diff-view").checked);
    const asrDiffColors = normalizeJudgementDiffColors(
      {
        changeBackground: getElement("judgement-diff-change-bg").value,
        gapBackground: getElement("judgement-diff-gap-bg").value,
        punctuationBackground: getElement("judgement-diff-punctuation-bg").value,
      },
      constants.DEFAULT_JUDGEMENT_ASR_CONFIG?.asrDiffColors
    );
    const compactCardEnabled = Boolean(getElement("judgement-compact-card").checked);
    const thunderQuestionEnabled = Boolean(getElement("judgement-thunder-question").checked);
    const autoAdvanceAfterChoice = Boolean(getElement("judgement-auto-advance").checked);
    const aiSuggestionEnabled = Boolean(getElement("judgement-ai-suggestion-enabled").checked);
    const aiSuggestionRequestTimeoutMs = clampNumber(
      Number(getElement("judgement-ai-suggestion-timeout").value),
      120000,
      1000,
      180000,
      0
    );
    const aiSuggestionAvailableModels = normalizeJudgementAiAvailableModels(
      constants.DEFAULT_JUDGEMENT_ASR_CONFIG?.aiSuggestionAvailableModels,
      judgementAiSuggestionModels
    );
    const aiSuggestionModel = normalizeJudgementAiModel(
      getElement("judgement-ai-suggestion-model").value,
      aiSuggestionAvailableModels,
      "qwen3-omni-flash"
    );
    const shortcuts = {};

    ensureShortcutDraft();
    judgementShortcutActions.forEach(function (action) {
      shortcuts[action.key] = normalizeShortcut(judgementShortcutsDraft[action.key]);
    });

    setStatus("judgement-status", "正在保存语音判别设置...");

    try {
      const defaultPlaybackRate = clampNumber(resetRateValue, 1.0, 0.25, 5, 2);
      currentSettings = await storage.saveProjectSettings(judgementProjectId, {
        volumeValue: clampNumber(volumeValue, 100, 0, 1000, 0),
        playbackRateValue: defaultPlaybackRate,
        rateStepValue: normalizeJudgementRateStep(rateStepValue, 0.25),
        seekStepSeconds: normalizeJudgementSeekStep(seekStepSeconds, 0.5),
        autoResetRate: true,
        resetRateValue: defaultPlaybackRate,
        itemsPerPage: itemsPerPage,
        autoPlay: autoPlay,
        virtualWindowEnabled: false,
        asrDiffViewEnabled: asrDiffViewEnabled,
        asrDiffColors: asrDiffColors,
        compactCardEnabled: compactCardEnabled,
        thunderQuestionEnabled: thunderQuestionEnabled,
        autoAdvanceAfterChoice: autoAdvanceAfterChoice,
        statsUploadEnabled: true,
        statsScheduleUrl: "",
        statsUploadTimes: constants.DEFAULT_JUDGEMENT_ASR_CONFIG?.statsUploadTimes || ["10:00", "16:00"],
        statsUploadJitterMinutes: constants.DEFAULT_JUDGEMENT_ASR_CONFIG?.statsUploadJitterMinutes || 10,
        statsAutoUploadOnSubtaskOpen: false,
        statsAutoUploadOnSchedule: true,
        statsUploadRequestTimeoutMs: 20000,
        aiSuggestionEnabled: aiSuggestionEnabled,
        aiSuggestionRequestTimeoutMs: aiSuggestionRequestTimeoutMs,
        aiSuggestionModel: aiSuggestionModel,
        aiSuggestionAvailableModels: aiSuggestionAvailableModels,
        shortcuts: shortcuts,
      });
      renderCurrentView();
      setStatus("judgement-status", "语音判别设置已保存；已打开的 LabelX 页面会尽量实时同步，未生效时请刷新页面。");
      return true;
    } catch (error) {
      setStatus(
        "judgement-status",
        "保存失败：" + (error && error.message ? error.message : String(error))
      );
      return false;
    }
  }

  async function renderCurrentView() {
    hideError();
    const scriptId = getCurrentDetailScriptId();
    const settings = currentSettings || (await loadSettings());

    document.title = (constants.EXTENSION_NAME || "标注脚本中心") + " - 设置";
    getElement("extension-name").textContent = constants.EXTENSION_NAME || "标注脚本中心";
    getElement("stage-label").textContent = constants.STAGE_LABEL || "脚本中心";

    if (!scriptId) {
      getElement("script-center-view").classList.remove("hidden");
      getElement("script-detail-view").classList.add("hidden");
      getElement("home-endpoint-card").classList.remove("hidden");
      renderScriptCenter(settings);
      return;
    }

    getElement("script-center-view").classList.add("hidden");
    getElement("script-detail-view").classList.remove("hidden");
    getElement("home-endpoint-card").classList.add("hidden");
    renderDetail(settings, scriptId);
  }

  document.addEventListener("DOMContentLoaded", async function () {
    getElement("back-to-center").addEventListener("click", function () {
      navigateToScript(null);
    });

    getElement("detail-enable-button").addEventListener("click", function () {
      const scriptId = getCurrentDetailScriptId();
      if (scriptId) {
        void toggleScript(scriptId, true);
      }
    });

    getElement("detail-disable-button").addEventListener("click", function () {
      const scriptId = getCurrentDetailScriptId();
      if (scriptId) {
        void toggleScript(scriptId, false);
      }
    });

    getElement("save-judgement-settings").addEventListener("click", function () {
      void saveJudgementSettings();
    });

    getElement("save-transcription-settings").addEventListener("click", function () {
      void saveTranscriptionSettings();
    });

    getElement("save-data-baker-settings").addEventListener("click", function () {
      void saveDataBakerSettings();
    });

    getElement("home-endpoint-server").addEventListener("click", function () {
      void setHomeBackendEndpoint("server");
    });

    getElement("home-endpoint-local").addEventListener("click", function () {
      void setHomeBackendEndpoint("local");
    });

    try {
      await loadSettings();
      await renderCurrentView();
    } catch (error) {
      showError(error && error.message ? error.message : String(error));
    }
  });
})();
