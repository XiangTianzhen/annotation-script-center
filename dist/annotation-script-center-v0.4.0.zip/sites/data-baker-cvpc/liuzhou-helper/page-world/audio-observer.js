(function () {
  const SOURCE = "ASR_EDGE_DATABAKER_CVPC_LIUZHOU_AUDIO_OBSERVER";
  const MESSAGE_TYPE = "DATABAKER_CVPC_LIUZHOU_AUDIO_MAPPING";
  const META_MESSAGE_TYPE = "DATABAKER_CVPC_LIUZHOU_META_SNAPSHOT";
  const META_PATH = "/httpapi/annotation/meta";
  const MAX_ENTRIES = 30;
  const AUDIO_EXT_PATTERN = /\.(mp3|wav|m4a|aac|ogg)(?:$|\?)/i;
  const AUDIO_URL_PATTERN = /https?:\/\/[^\s"'<>]+?\.(?:mp3|wav|m4a|aac|ogg)(?:\?[^\s"'<>]*)?/gi;

  function normalizeText(value) {
    return String(value || "").replace(/\s+/g, " ").trim();
  }

  function normalizePath(value) {
    return normalizeText(value)
      .replace(/^https?:\/\/[^/]+/i, "")
      .replace(/^\//, "");
  }

  function getUrl(rawUrl, locationLike) {
    try {
      return new URL(String(rawUrl || ""), locationLike?.href || "https://cvpc.data-baker.com/");
    } catch (error) {
      return null;
    }
  }

  function isMetaUrl(rawUrl, locationLike) {
    const url = getUrl(rawUrl, locationLike);
    return Boolean(url && url.pathname === META_PATH);
  }

  function extractQuery(rawUrl, locationLike) {
    const url = getUrl(rawUrl, locationLike);
    const result = {};
    if (!url) {
      return result;
    }
    url.searchParams.forEach(function (value, key) {
      result[key] = value;
    });
    return result;
  }

  function isAudioUrl(rawUrl, locationLike) {
    const url = getUrl(rawUrl, locationLike);
    if (!url) {
      return false;
    }
    return AUDIO_EXT_PATTERN.test(url.pathname);
  }

  function extractFileName(value) {
    const path = normalizePath(value).split("?")[0];
    return normalizeText(path.split("/").pop());
  }

  function extractEntries(payload) {
    const source = payload && typeof payload === "object" ? payload : {};
    const datas = Array.isArray(source?.data?.datas)
      ? source.data.datas
      : Array.isArray(source?.datas)
        ? source.datas
        : [];
    return datas
      .map(function (item) {
        const row = item && typeof item === "object" ? item : {};
        const relativePath = normalizePath(row.content);
        const fileName = normalizeText(row.name) || extractFileName(relativePath);
        return {
          entryId: normalizeText(row.entry_id),
          entryIndex: normalizeText(row.entry_index),
          relativePath,
          fileName,
        };
      })
      .filter(function (item) {
        return item.relativePath || item.fileName;
      });
  }

  function createObserver(options) {
    const deps = options && typeof options === "object" ? options : {};
    const windowLike = deps.window || globalThis.window || globalThis;
    const locationLike = deps.location || windowLike.location || globalThis.location || {};
    const entries = [];
    const mappings = new Map();
    const pendingAudioUrls = [];
    let installed = false;

    function notify(mapping) {
      if (!mapping || typeof windowLike.postMessage !== "function") {
        return;
      }
      windowLike.postMessage(
        {
          source: SOURCE,
          type: MESSAGE_TYPE,
          payload: mapping,
        },
        locationLike.origin || "*"
      );
    }

    function notifyMeta(rawUrl, meta) {
      if (!meta || typeof meta !== "object" || typeof windowLike.postMessage !== "function") {
        return;
      }
      windowLike.postMessage(
        {
          source: SOURCE,
          type: META_MESSAGE_TYPE,
          payload: {
            meta,
            query: extractQuery(rawUrl, locationLike),
            at: Date.now(),
          },
        },
        locationLike.origin || "*"
      );
    }

    function rememberEntries(nextEntries) {
      const list = Array.isArray(nextEntries) ? nextEntries : [];
      list.forEach(function (entry) {
        entries.unshift(entry);
      });
      entries.splice(MAX_ENTRIES);
      pendingAudioUrls.slice().forEach(function (url) {
        rememberAudioUrl(url);
      });
    }

    function matchEntry(rawAudioUrl) {
      const url = getUrl(rawAudioUrl, locationLike);
      if (!url) {
        return null;
      }
      const audioPath = normalizePath(url.pathname);
      const audioFileName = extractFileName(url.pathname);
      return (
        entries.find(function (entry) {
          return entry.relativePath && audioPath.endsWith(entry.relativePath);
        }) ||
        entries.find(function (entry) {
          return entry.fileName && audioFileName === entry.fileName;
        }) ||
        null
      );
    }

    function rememberAudioUrl(rawAudioUrl) {
      const audioUrl = normalizeText(rawAudioUrl);
      if (!audioUrl || !isAudioUrl(audioUrl, locationLike)) {
        return null;
      }
      const entry = matchEntry(audioUrl);
      if (!entry) {
        pendingAudioUrls.unshift(audioUrl);
        pendingAudioUrls.splice(MAX_ENTRIES);
        return null;
      }
      const key = entry.relativePath || entry.fileName;
      const mapping = {
        relativePath: entry.relativePath,
        fileName: entry.fileName,
        entryId: entry.entryId,
        entryIndex: entry.entryIndex,
        audioUrl,
        at: Date.now(),
      };
      mappings.set(key, mapping);
      notify(mapping);
      return mapping;
    }

    function collectAudioUrlsFromValue(value, results, depth) {
      if (depth > 3 || results.length >= MAX_ENTRIES) {
        return;
      }
      if (typeof value === "string") {
        const matches = value.match(AUDIO_URL_PATTERN) || [];
        matches.forEach(function (item) {
          if (results.indexOf(item) < 0) {
            results.push(item);
          }
        });
        return;
      }
      if (Array.isArray(value)) {
        value.forEach(function (item) {
          collectAudioUrlsFromValue(item, results, depth + 1);
        });
        return;
      }
      if (value && typeof value === "object") {
        Object.keys(value)
          .slice(0, MAX_ENTRIES)
          .forEach(function (key) {
            collectAudioUrlsFromValue(value[key], results, depth + 1);
          });
      }
    }

    function observeConsoleArgs(args) {
      const urls = [];
      Array.from(args || []).forEach(function (item) {
        collectAudioUrlsFromValue(item, urls, 0);
      });
      urls.forEach(function (url) {
        observeAudioUrl(url);
      });
    }

    function observeResponse(rawUrl, responseText) {
      if (!isMetaUrl(rawUrl, locationLike)) {
        return;
      }
      try {
        const payload = JSON.parse(String(responseText || "{}"));
        rememberEntries(extractEntries(payload));
        const meta = payload && typeof payload === "object" && payload.data ? payload.data : payload;
        notifyMeta(rawUrl, meta);
      } catch (error) {
        // Ignore partial or non-JSON responses.
      }
    }

    function observeAudioUrl(rawUrl) {
      return rememberAudioUrl(rawUrl);
    }

    function installFetchObserver() {
      const nativeFetch = windowLike.fetch;
      if (typeof nativeFetch !== "function") {
        return;
      }
      windowLike.fetch = function () {
        const args = Array.from(arguments);
        const input = args[0];
        const rawUrl =
          typeof input === "string"
            ? input
            : input && typeof input.url === "string"
              ? input.url
              : "";
        observeAudioUrl(rawUrl);
        return nativeFetch.apply(this, args).then(function (response) {
          if (!isMetaUrl(rawUrl, locationLike)) {
            return response;
          }
          try {
            response
              .clone()
              .text()
              .then(function (text) {
                observeResponse(rawUrl, text);
              })
              .catch(function () {});
          } catch (error) {
            // Keep page behavior unchanged if response cloning fails.
          }
          return response;
        });
      };
    }

    function installXhrObserver() {
      const NativeXhr = windowLike.XMLHttpRequest;
      if (typeof NativeXhr !== "function") {
        return;
      }
      const nativeOpen = NativeXhr.prototype.open;
      const nativeSend = NativeXhr.prototype.send;
      if (typeof nativeOpen !== "function" || typeof nativeSend !== "function") {
        return;
      }
      NativeXhr.prototype.open = function (method, url) {
        this.__ascCvpcLiuzhouAudioUrl = String(url || "");
        observeAudioUrl(this.__ascCvpcLiuzhouAudioUrl);
        return nativeOpen.apply(this, arguments);
      };
      NativeXhr.prototype.send = function () {
        const xhr = this;
        const rawUrl = xhr.__ascCvpcLiuzhouAudioUrl || "";
        if (isMetaUrl(rawUrl, locationLike) && typeof xhr.addEventListener === "function") {
          xhr.addEventListener("load", function () {
            observeResponse(rawUrl, xhr.responseText);
          });
        }
        return nativeSend.apply(this, arguments);
      };
    }

    function installConsoleObserver() {
      const consoleLike = windowLike.console;
      if (!consoleLike) {
        return;
      }
      ["log", "info", "debug", "warn"].forEach(function (method) {
        if (typeof consoleLike[method] !== "function") {
          return;
        }
        const nativeMethod = consoleLike[method];
        consoleLike[method] = function () {
          try {
            observeConsoleArgs(arguments);
          } catch (error) {
            // Keep platform console behavior unchanged.
          }
          return nativeMethod.apply(this, arguments);
        };
      });
    }

    function install() {
      if (installed) {
        return;
      }
      installed = true;
      installFetchObserver();
      installXhrObserver();
      installConsoleObserver();
    }

    function getSnapshot() {
      return {
        entries: entries.slice(),
        mappings: Array.from(mappings.values()).sort(function (left, right) {
          return Number(right.at || 0) - Number(left.at || 0);
        }),
      };
    }

    return {
      getSnapshot,
      install,
      observeAudioUrl,
      observeConsoleArgs,
      observeResponse,
    };
  }

  const api = {
    createObserver,
    constants: {
      MESSAGE_TYPE,
      SOURCE,
      META_MESSAGE_TYPE,
    },
  };

  globalThis.ASREdgeDataBakerCvpcLiuzhouAudioObserverPage = api;

  if (typeof module !== "undefined" && module.exports) {
    module.exports = api;
  }

  if (typeof window !== "undefined") {
    const flag = "__ASREdgeDataBakerCvpcLiuzhouAudioObserverInstalled";
    if (!window[flag]) {
      window[flag] = true;
      createObserver({ window, location: window.location }).install();
    }
  }
})();
