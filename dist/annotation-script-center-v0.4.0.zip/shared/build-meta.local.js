(function () {
  globalThis.ASREdgeBuildMeta = globalThis.ASREdgeBuildMeta || {};
})();
